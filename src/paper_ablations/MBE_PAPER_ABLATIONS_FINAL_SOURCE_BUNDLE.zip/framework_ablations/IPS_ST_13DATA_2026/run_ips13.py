#!/usr/bin/env python3
"""Paired 2026 official IPS vs selective-index + compact-state IPS ST.

IMPORTANT: This benchmark uses the official IPS aggregate MBE count, which may
sum combinations for matching terminals. It is *not* a per-biclique output test.
All reported search times come from IPS_t::run() and exclude graph construction.
"""
import argparse
import csv
import gc
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import signal
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
DATASETS = ['youtube', 'actors', 'stackoverflow', 'bibsonomy', 'dblp',
            'forum', 'ukwiki', 'escorts', 'github', 'bkcrossing',
            'twitter', 'imdb', 'amazon']
EXPECTED = dict(youtube=1826587, actors=1075444, stackoverflow=3320824,
                bibsonomy=2507269, dblp=4899032, forum=16261,
                ukwiki=23772, escorts=49538, github=55346398,
                bkcrossing=54458953, twitter=5536526,
                imdb=5160061, amazon=7551358)
CONFIGS = {
    'official_ips': (None, None),
    'ips_st': ('ON', 'ON'),
    'ips_compact': ('ON', 'OFF'),
    'ips_hybrid': ('OFF', 'ON'),
}
FIELDS = ['dataset', 'order', 'config', 'rep', 'status', 'search_ms',
          'rss_mib', 'wall_s', 'count', 'expected', 'edges', 'error']


def log(file, message):
    print(message, flush=True)
    file.parent.mkdir(parents=True, exist_ok=True)
    with file.open('a', encoding='utf-8') as o:
        o.write(message + '\n')


def build(name, report, jobs):
    compact, hybrid = CONFIGS[name]
    source = HERE / ('source_official' if compact is None else 'source_enhanced')
    dest = HERE / ('build_' + name)
    command = ['cmake', '-S', str(source), '-B', str(dest),
               '-DCMAKE_BUILD_TYPE=Release',
               # Caution: IPS graph.hpp reads the header in assert(fscanf(...)).
               # Stock -DNDEBUG skips graph header parsing and breaks the binary.
               '-DCMAKE_CXX_FLAGS_RELEASE=-O3 -UNDEBUG']
    if compact is not None:
        command += ['-DIPS_ST_COMPACT=' + compact, '-DIPS_ST_HYBRID=' + hybrid]
    for cmd in (command, ['cmake', '--build', str(dest), '--parallel', str(jobs)]):
        log(report, '[BUILD] ' + ' '.join(cmd))
        p = subprocess.run(cmd, text=True, capture_output=True)
        if p.returncode:
            raise RuntimeError(f'Build {name} failed:\n{p.stdout[-1500:]}\n{p.stderr[-2500:]}')
    exe = dest / 'ips'
    if not exe.is_file():
        raise RuntimeError(f'Missing executable after build: {exe}')
    return exe


def cpu_affinity(arg):
    if arg.lower() == 'none':
        return None
    if not shutil.which('taskset'):
        if arg == 'auto':
            return None
        raise RuntimeError('taskset not installed; use --cpu none')
    allowed = os.sched_getaffinity(0) if hasattr(os, 'sched_getaffinity') else None
    if arg == 'auto':
        return min(allowed) if allowed else None
    core = int(arg)
    if allowed is not None and core not in allowed:
        raise RuntimeError('CPU not in affinity mask: ' + str(sorted(allowed)))
    return core


def source_stamp(path):
    st = path.stat()
    return dict(path=str(path.resolve()), size=st.st_size, mtime_ns=st.st_mtime_ns)


def normalize_2col(src, target):
    """Deduplicate edges and independently reindex both sides to 0-based.

    Original MBET data_clean is not necessarily in IPS's required format.
    We use one *identical* normalized input for both IPS configurations.
    A 3-integer header, if present, is consumed, not treated as an edge.
    Isolated vertices are discarded (do not participate in nonempty bicliques).
    Data cleaning is separate from search timing.
    """
    meta_file = target.with_suffix('.meta.json')
    stamp = source_stamp(src)
    if target.exists() and meta_file.exists():
        try:
            prev = json.loads(meta_file.read_text())
            if prev.get('source') == stamp and prev.get('converter') == 2 and target.stat().st_size:
                return prev
        except (OSError, ValueError):
            pass
    target.parent.mkdir(parents=True, exist_ok=True)
    edges = set()
    header = False
    first_data = True
    with src.open('r', encoding='utf-8', errors='replace') as f:
        for ln, line in enumerate(f, 1):
            stripped = line.strip()
            if not stripped or stripped.startswith(('#', '%', '//')):
                continue
            tokens = stripped.split()
            if first_data:
                first_data = False
                if len(tokens) == 3 and all(x.lstrip('+-').isdigit() for x in tokens):
                    header = True
                    continue
            if len(tokens) < 2:
                raise ValueError(f'{src.name}:{ln} expected two integer endpoints')
            try:
                u = int(tokens[0]);v = int(tokens[1])
            except ValueError as ex:
                raise ValueError(f'{src.name}:{ln} invalid graph edge') from ex
            edges.add((u, v))
    if not edges:
        raise ValueError('Empty graph: ' + str(src))
    left = sorted({e[0] for e in edges})
    right = sorted({e[1] for e in edges})
    if max(len(left),len(right),len(edges)) > 2147483647:
        raise ValueError('IPS uses 32-bit integers: input too large')
    lmap = {k:i for i,k in enumerate(left)}
    rmap = {k:i for i,k in enumerate(right)}
    tmp = target.with_suffix('.partial')
    ordered_edges = sorted((lmap[u], rmap[v]) for u,v in edges)
    del edges, lmap, rmap, left, right
    gc.collect()
    try:
        with tmp.open('w') as out:
            n1 = ordered_edges[-1][0]+1
            n2 = max(v for u,v in ordered_edges)+1
            out.write(f'{n1} {n2} {len(ordered_edges)}\n')
            for u,v in ordered_edges:
                out.write(f'{u} {v}\n')
        os.replace(tmp,target)
    finally:
        tmp.unlink(missing_ok=True)
    result = dict(converter=2, source=stamp, header_removed=header,
                  n_left=n1, n_right=n2, edges=len(ordered_edges))
    meta_file.write_text(json.dumps(result, indent=2))
    del ordered_edges
    gc.collect()
    return result


def run_one(exe, graph, dataset, order, config, rep, core, timeout_s, expected, edges):
    cmd = [str(exe), '-f', str(graph), '-d', order, '-l', '1', '-r', '1']
    if core is not None:
        cmd = ['taskset', '-c', str(core)] + cmd
    if Path('/usr/bin/time').exists():
        cmd = ['/usr/bin/time', '-f', '__IPS13_RSS_KB=%M'] + cmd
    result = dict(dataset=dataset, order=order, config=config, rep=rep,
                  expected=expected, edges=edges)
    start = time.monotonic()
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         text=True, errors='replace', start_new_session=True)
    try:
        out, err = p.communicate(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        p.communicate()
        return dict(result, status='TIMEOUT', wall_s=round(time.monotonic()-start, 3), error='TIMEOUT')
    except KeyboardInterrupt:
        os.killpg(p.pid, signal.SIGKILL)
        p.communicate()
        raise
    result['wall_s'] = round(time.monotonic()-start, 4)
    if p.returncode != 0:
        return dict(result, status='ERROR', error=f'exit {p.returncode}: ' + (out+err)[-450:])
    matches = re.findall(r'Maximal_BiClique_Count:\s*(\d+),\s*Time:\s*(\d+)\s*ms', out)
    if not matches:
        return dict(result, status='INVALID', error='Missing official IPS final count/time: '+out[-280:])
    count, ms = (int(x) for x in matches[-1])
    result.update(status='OK', count=count, search_ms=ms)
    m = re.search(r'__IPS13_RSS_KB=(\d+)', err)
    if m:
        result['rss_mib'] = round(int(m.group(1))/1024, 2)
    if expected is not None and count != expected:
        result.update(status='MISMATCH', error=f'IPS count {count} differs from V42 one-sided reference {expected}')
    return result


def write_csv(file, row):
    first = not file.exists()
    with file.open('a', newline='') as f:
        writer = csv.DictWriter(f, FIELDS, extrasaction='ignore')
        if first: writer.writeheader()
        writer.writerow(row)


def get_rows(file):
    if not file.exists(): return []
    with file.open(newline='') as f: return list(csv.DictReader(f))


def median(xs):
    return statistics.median(xs) if xs else None


def summarize(rows, datasets, configs, order, reps, out, log_file):
    table = []
    for ds in datasets:
        values = {}
        for config in configs:
            subset = [r for r in rows if r.get('dataset') == ds and r.get('order') == order
                      and r.get('config') == config and r.get('status') == 'OK']
            good = len(set(int(r['rep']) for r in subset))
            values[config] = (median([float(r['search_ms']) for r in subset]),
                              median([float(r['rss_mib']) for r in subset if r.get('rss_mib')]),good)
        orig, base_rss, base_n = values.get('official_ips', (None,None,0))
        st, st_rss, st_n = values.get('ips_st',(None,None,0))
        speed = orig/st if orig is not None and st and base_n == reps and st_n == reps else None
        complete = all(values[c][2] == reps for c in configs)
        table.append(dict(dataset=ds, official_ms=orig, st_ms=st,
                          official_rss_mib=base_rss, st_rss_mib=st_rss,
                          speedup=speed, complete=complete,
                          **{c+'_n':values[c][2] for c in configs},
                          **{c+'_ms':values[c][0] for c in configs}))
    keys = list(dict.fromkeys(k for r in table for k in r))
    with out.open('w',newline='') as f:
        writer=csv.DictWriter(f,keys)
        writer.writeheader();writer.writerows(table)
    log(log_file,'\n[SUMMARY] 2026 IPS official versus IPS+ST: '+str(out))
    for r in table:
        if r['speedup']:
            log(log_file,f"[SUMMARY] {r['dataset']:<14} official={r['official_ms'] / 1000:.3f}s st={r['st_ms']/1000:.3f}s speedup={r['speedup']:.4f}x complete={r['complete']}")
        else:
            log(log_file,f"[SUMMARY] {r['dataset']:<14} INCOMPLETE / NO VALID SPEEDUP (see CSV)")
    import math
    vals=[r['speedup'] for r in table if r['speedup'] is not None]
    if vals:
        log(log_file,f'[SUMMARY] matched={len(vals)}/{len(table)} geometric_mean={math.exp(sum(math.log(v) for v in vals)/len(vals)):.4f}x')
    return table


def oracle(binary_map, report, order=('two','core')):
    # Small independent oracle (not merely baseline vs enhanced agreement).
    import itertools
    rng = random.Random(843)
    cases=[]
    for i in range(32):
        n=rng.randint(3,7);m=rng.randint(3,7)
        prob=(0.15,0.4,0.7,0.9)[i%4]
        edges={(u,v) for u in range(n) for v in range(m) if rng.random()<prob}
        cnt=0
        for mask in range(1,1<<n):
            L=[u for u in range(n) if mask>>u&1]
            R=[v for v in range(m) if all((u,v) in edges for u in L)]
            if not R: continue
            if any(all((u,v) in edges for v in R) for u in range(n) if u not in L):continue
            cnt+=1
        cases.append((i,n,m,edges,cnt))
    # Also activate hybrid bit-index path: n=320, K_{320,320} -> 1 result.
    cases.append((32,320,320,{(u,v) for u in range(320) for v in range(320)},1))
    d = HERE / 'oracle_cases';d.mkdir(exist_ok=True)
    attempts=0
    for i,n,m,edges,expected in cases:
        graph=d / f'case{i:02d}.clean'
        with graph.open('w') as f:
            f.write(f'{n} {m} {len(edges)}\n')
            for u,v in sorted(edges): f.write(f'{u} {v}\n')
        for vertex_order in order:
            for name,exe in binary_map.items():
                p=subprocess.run([str(exe),'-f',str(graph),'-d',vertex_order],
                                 text=True,capture_output=True,timeout=20)
                matches=re.findall(r'Maximal_BiClique_Count:\s*(\d+),',p.stdout)
                if p.returncode!=0 or not matches or int(matches[-1])!=expected:
                    raise RuntimeError(f'Oracle FAIL graph={i} order={vertex_order} config={name} expected={expected} '
                                       f'code={p.returncode} out={p.stdout[-700:]} err={p.stderr[-300:]}')
                attempts+=1
    log(report,f'[ORACLE] PASS {len(cases)} graphs x {len(tuple(order))} orders x {len(binary_map)} variants = {attempts} exact counts')


def main():
    ap = argparse.ArgumentParser(description='2026 IPS versus compatible double-side ST on 13 real bipartite datasets')
    ap.add_argument('--project-root',type=Path,default=Path.cwd())
    ap.add_argument('--datasets',nargs='+',choices=DATASETS,default=DATASETS)
    ap.add_argument('--configs',nargs='+',choices=list(CONFIGS),default=['official_ips','ips_st'])
    ap.add_argument('--order',choices=['two','core'],default='two')
    ap.add_argument('--runs',type=int,default=int(os.getenv('RUNS','5')))
    ap.add_argument('--timeout',type=int,default=int(os.getenv('TIMEOUT','600')))
    ap.add_argument('--cpu',default=os.getenv('CPU','auto'))
    ap.add_argument('--jobs',type=int,default=2)
    ap.add_argument('--skip-build',action='store_true')
    ap.add_argument('--skip-oracle',action='store_true')
    ap.add_argument('--resume',action='store_true')
    ap.add_argument('--smoke',action='store_true')
    ap.add_argument('--report',type=Path,default=None)
    args=ap.parse_args()
    if args.runs<1 or args.timeout<1 or args.jobs<1:
        ap.error('runs, timeout, and jobs must be positive')
    if len(set(args.configs))!=len(args.configs) or len(set(args.datasets))!=len(args.datasets):
        ap.error('Duplicate configs or datasets')
    root=args.project_root.resolve()
    output=root/'diagnostics'/'IPS_ST13'
    default_report=output/('IPS_ST13_SMOKE.txt' if args.smoke else 'IPS_ST13_PILOT.txt')
    report=(args.report or default_report).resolve()
    report.parent.mkdir(parents=True,exist_ok=True)
    csv_file=report.with_suffix('.csv')
    manifest_file=report.with_suffix('.manifest.json')
    summary_file=report.with_name(report.stem+'_SUMMARY.csv')
    cpu=cpu_affinity(args.cpu)
    chosen=['youtube'] if args.smoke else args.datasets
    if not args.smoke:
        missing=[str(root/'data_clean'/f'{x}.txt') for x in chosen if not (root/'data_clean'/f'{x}.txt').is_file()]
        if missing:
            raise FileNotFoundError('Missing data_clean inputs:\n'+'\n'.join(missing))
    if not args.resume:
        report.write_text('')
        for p in (csv_file,manifest_file,summary_file):p.unlink(missing_ok=True)
    log(report,f'[START] order={args.order} datasets={chosen} configs={args.configs} runs={args.runs} cpu={cpu} timeout={args.timeout}s')
    binaries={}
    signatures={}
    for c in args.configs:
        exe=HERE/('build_'+c)/'ips' if args.skip_build else build(c,report,args.jobs)
        if not exe.exists():raise RuntimeError('Missing binary '+str(exe))
        binaries[c]=exe
        signatures[c]=hashlib.sha256(exe.read_bytes()).hexdigest()
        log(report,f'[BIN] {c} sha256={signatures[c]}')
    manifest=dict(datasets=chosen,configs=args.configs,order=args.order,
                  runs=args.runs,cpu=cpu,smoke=args.smoke,signatures=signatures)
    if args.resume:
        if not manifest_file.exists():raise RuntimeError('No manifest for --resume')
        if json.loads(manifest_file.read_text())!=manifest:
            raise RuntimeError('Resume manifest mismatch: use same parameters and binaries')
    else:
        manifest_file.write_text(json.dumps(manifest,indent=2))
    if not args.skip_oracle:
        oracle(binaries,report)
    if args.smoke:
        # Generate fixture even when --skip-oracle is specified.
        fixture = HERE / 'oracle_cases' / 'smoke.clean'
        fixture.parent.mkdir(parents=True, exist_ok=True)
        # K_{4,4} plus a leaf: two nonempty maximal bicliques.
        ed = [(u,v) for u in range(4) for v in range(4)] + [(4,4)]
        with fixture.open('w') as f:
            f.write(f'5 5 {len(ed)}\n')
            for u,v in ed: f.write(f'{u} {v}\n')
    completed={(r['dataset'],r['order'],r['config'],int(r['rep'])) for r in get_rows(csv_file)
               if r.get('status')=='OK'}
    rng=random.Random(202613)
    begin=time.monotonic()
    for dataset in chosen:
        if args.smoke:
            graph=HERE/'oracle_cases'/'smoke.clean'
            info=dict(edges=17)
            expected=2
        else:
            graph=report.parent/'ips_clean_cache'/f'{dataset}.clean'
            info=normalize_2col(root/'data_clean'/f'{dataset}.txt',graph)
            expected=EXPECTED[dataset]
        log(report,f'\n[DATASET] {dataset} graph={graph} edges={info["edges"]} expected={expected}')
        for rep in range(1,args.runs+1):
            orderlist=list(args.configs)
            rng.shuffle(orderlist)
            for name in orderlist:
                if (dataset,args.order,name,rep) in completed:
                    continue
                row=run_one(binaries[name],graph,dataset,args.order,name,rep,cpu,args.timeout,expected,info['edges'])
                write_csv(csv_file,row)
                log(report,f'[RUN] {dataset} order={args.order} config={name} rep={rep} status={row["status"]} '
                    f'search_ms={row.get("search_ms","NA")} wall_s={row.get("wall_s","NA")} '
                    f'rss_mib={row.get("rss_mib","NA")} count={row.get("count","NA")} '+
                    (f'error={row["error"]}' if row.get('error') else ''))
                if row['status']=='OK':completed.add((dataset,args.order,name,rep))
        rows=get_rows(csv_file)
        for c in args.configs:
            cur=[r for r in rows if r.get('dataset')==dataset and r.get('config')==c and r.get('status')=='OK'
                 and r.get('order')==args.order]
            if cur:
                log(report,f'[MEDIAN] {dataset} config={c} {len(cur)}/{args.runs} search_ms='+
                    f'{statistics.median(float(r["search_ms"]) for r in cur):.3f}')
        summarize(rows,chosen,args.configs,args.order,args.runs,summary_file,report)
    log(report,f'[DONE] wall_s={time.monotonic()-begin:.2f} report={report} csv={csv_file} summary={summary_file}')
    if not args.smoke:
        log(report,'[NOTE] Official IPS uses aggregate combination counts in some matching terminal states; this is NOT per-result materialization.')
        log(report,'[NOTE] The current double-side ST reconstruction is evaluated against official IPS under identical counting semantics.')

if __name__=='__main__':
    try: main()
    except (RuntimeError,FileNotFoundError,ValueError) as exc:
        print('[ERROR] '+str(exc),file=sys.stderr,flush=True)
        sys.exit(2)
