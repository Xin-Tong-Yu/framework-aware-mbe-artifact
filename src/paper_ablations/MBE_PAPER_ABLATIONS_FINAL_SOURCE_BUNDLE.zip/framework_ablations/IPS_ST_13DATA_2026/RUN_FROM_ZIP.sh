#!/usr/bin/env bash
set -euo pipefail
ZIP="${1:-IPS_ST_13DATA_2026.zip}"
shift || true
ROOT="$PWD"
PKG=IPS_ST_13DATA_2026
if [[ ! -f "$ZIP" ]]; then
  echo "ZIP not found: $ZIP" >&2
  exit 1
fi
unzip -q -o "$ZIP" "$PKG/*" -d "$ROOT"
bash "$ROOT/$PKG/run_13.sh" "$@"
