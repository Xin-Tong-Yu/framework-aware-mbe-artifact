# Native IPS published comparison

Original IPS source compared against an enhanced native implementation under the original count-aggregation reporting protocol. Run `bash run_experiments.sh ips-native-baseline --runs 5 --timeout 1200`. Do not equate it to explicit per-result generation.

All run logs, timestamps, source hashes and dataset identifiers should be retained when reporting new measurements.
