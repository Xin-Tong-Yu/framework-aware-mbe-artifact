#!/usr/bin/env python3
"""V62: resumable, drift-controlled, 13-graph paired-block Release-only MBET benchmark."""
from __future__ import annotations
import argparse, hashlib, json, math, os, platform, random, resource, shutil, statistics, subprocess, sys, tempfile, time, traceback
from pathlib import Path
import v57_run as base

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent
REPORT=PROJECT/'diagnostics'/'V62_ALL_RESULTS.txt'
CACHE=PROJECT/'diagnostics'/'V62_CHECKPOINT.json'
DATASETS=['youtube','actors','stackoverflow','bibsonomy','dblp','forum','ukwiki','escorts','github','bkcrossing','twitter','imdb','amazon']
BASE='--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v57-mask-prefix on --v57-mask-fast-closure on --v56-min-paths 8 --v59-dispatch 1 --v59-work-gate 96 --v60-lazy-mask on --v60-root-gate on'.split()
MODES={
 'st_only':base.BINARY_MODES['st_only'],
 'd_prefork':base.BINARY_MODES['d_prefork'],
 'v60_root_lazy':BASE,
 'v60_root_lazy_d':BASE+['--v56-prefork','on'],
 'v62_emit':BASE+['--v61-fast-emit','on'],
 'v62_emit_d':BASE+['--v61-fast-emit','on','--v56-prefork','on'],
 'v62_tree':BASE+['--v62-tree-mask','on'],
 'v62_tree_emit':BASE+['--v62-tree-mask','on','--v61-fast-emit','on'],
 'v62_cursor':BASE+['--v62-tree-mask','on','--v62-mask-cursor','on'],
 'v62_cursor_emit':BASE+['--v62-tree-mask','on','--v62-mask-cursor','on','--v61-fast-emit','on'],
 'v62_cursor_emit_d':BASE+['--v62-tree-mask','on','--v62-mask-cursor','on','--v61-fast-emit','on','--v56-prefork','on'],
 'v62_tree_emit_d':BASE+['--v62-tree-mask','on','--v61-fast-emit','on','--v56-prefork','on'],
 'v62_tree_emit_work128':BASE+['--v62-tree-mask','on','--v61-fast-emit','on','--v59-work-gate','128'],
 'v62_emit_sort':BASE+['--v61-fast-emit','on','--v61-fast-sort','on'],
}
ORIGINAL_MODES=base.BINARY_MODES.copy()
base.BINARY_MODES={**MODES,'b_ref':ORIGINAL_MODES['b_ref']}
FLAGS=[*base.COMPILER,'-DMBE_V61_FAST_RESULT_APPEND=OFF','-DMBE_ET13_DIAG=OFF','-DMBE_V58_COST_PROFILE=OFF']

def log(s=''):
 print(s,flush=True)
 with REPORT.open('a',encoding='utf-8') as f:f.write(s+'\n')

def persist(obj):
 CACHE.parent.mkdir(parents=True,exist_ok=True)
 p=CACHE.with_suffix('.json.tmp')
 p.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True),encoding='utf-8')
 os.replace(p,CACHE)

def build():
 dest=HERE/'build_v62'
 for cmd in [['cmake','-S',str(HERE/'source'),'-B',str(dest),*FLAGS], ['cmake','--build',str(dest),'--parallel','2']]:
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=450)
  if p.returncode:raise RuntimeError(f'{cmd}\n{p.stdout[-2500:]}\n{p.stderr[-2500:]}')
 exe=dest/'mbet_fast'
 return exe,base.digest(exe)

def filename(ds,root):
 for d in [root, PROJECT/'data_clean',HERE/'data']:
  if d is not None:
   p=Path(d)/(ds+'.txt')
   if p.is_file():return p
 return None

def has_complete(block,modes):
 return all(k in block and isinstance(block[k],dict) and 'ms' in block[k] for k in ['st_begin',*modes,'st_end'])

def paired_stats(block,modes):
 beg=block['st_begin'];end=block['st_end']; t0=beg['clock'];t1=end['clock'];denom=max(1e-6,t1-t0)
 result={}
 for mode in modes:
  x=block[mode]
  weight=max(0.0,min(1.0,(x['clock']-t0)/denom))
  estimated=beg['ms']+(end['ms']-beg['ms'])*weight
  result[mode]=estimated/x['ms']
 return result

def geometric(a):return math.exp(sum(math.log(x) for x in a)/len(a)) if a else float('nan')

def report_summary(store,args,problems,exe_sha):
 log('\n=== V62 CROSS-DATASET PAIR-BLOCK SUMMARY ===')
 complete={};partial=[]
 for ds in args.datasets:
  item=store.get('datasets',{}).get(ds,{})
  blocks=[]
  for rep in range(args.runs):
   rec=item.get('blocks',{}).get(str(rep),{})
   if has_complete(rec,[m for m in args.modes if m!='st_only']):blocks.append(rec)
  if len(blocks)==args.runs:
   complete[ds]=blocks
  else:
   partial.append((ds,len(blocks),args.runs))
 log(f'[COMPLETED_DATASETS] {list(complete)}')
 log(f'[PARTIAL_OR_MISSING] {partial}')
 log(f'[FAILED_DETAILS] {problems}')
 for ds,blocks in complete.items():
  pairs=[paired_stats(b,[m for m in args.modes if m!='st_only']) for b in blocks]
  sig=blocks[0]['st_begin']['signature']
  median_base=statistics.median([(b['st_begin']['ms']+b['st_end']['ms'])/2 for b in blocks])
  log(f'[DATASET] {ds} checksum={sig} runs={len(blocks)} st_anchor_mid_median_ms={median_base:.3f} PASS')
  changes=[b['st_end']['ms']/b['st_begin']['ms']-1 for b in blocks]
  log(f'[DRIFT] {ds} anchor_end_vs_begin_pct={list(round(v*100,2) for v in changes)}')
  for m in args.modes:
   if m=='st_only':continue
   obs=[p[m] for p in pairs]
   raw=statistics.median(b[m]['ms'] for b in blocks)
   log(f'[PAIRED] dataset={ds} mode={m} median_speedup={statistics.median(obs):.5f}x gm_blocks={geometric(obs):.5f}x raw_median_ms={raw:.3f} block_ratios={list(round(v,5) for v in obs)}')
 for m in args.modes:
  if m=='st_only':continue
  vals=[statistics.median([paired_stats(b,[m])[m] for b in blocks]) for ds,blocks in complete.items()]
  if not vals:continue
  win=sum(v>1.02 for v in vals)
  lose=sum(v<1.0 for v in vals)
  log(f'[GM_PAIRED] mode={m} datasets={len(vals)} gm_vs_ST={geometric(vals):.5f}x wins_over_2pct={win}/{len(vals)} losses={lose}/{len(vals)}')
  if 'd_prefork' in args.modes and m!='d_prefork':
   against_d=[statistics.median([paired_stats(b,[m,'d_prefork'])[m]/paired_stats(b,[m,'d_prefork'])['d_prefork'] for b in blocks]) for ds,blocks in complete.items()]
   log(f'[GM_VS_D] mode={m} datasets={len(against_d)} gm_vs_D={geometric(against_d):.5f}x wins_over_2pct={sum(x>1.02 for x in against_d)}/{len(against_d)}')
  if len(vals)==len(args.datasets) and len(vals)>=4 and win >= (len(vals)//2+1):
   log(f'[TARGET_CANDIDATE] mode={m} more_than_half_of_all_datasets_above_2pct=YES; requires repeated independent batch for stability')
 log(f'[COMPLETE] done={len(complete)}/{len(args.datasets)} all_complete={len(complete)==len(args.datasets)} executable_sha256={exe_sha}')
 log(f'[CHECKPOINT] {CACHE}')
 log(f'[OUTPUT] {REPORT}')
 return len(complete)

def main():
 ap=argparse.ArgumentParser(description='V62 13-dataset paired randomized block benchmark, with resume checkpoints')
 ap.add_argument('--datasets',nargs='+',default=DATASETS)
 ap.add_argument('--data-root',type=Path,default=None)
 ap.add_argument('--runs',type=int,default=5)
 ap.add_argument('--timeout',type=int,default=1200)
 ap.add_argument('--cpu',default='auto')
 ap.add_argument('--min-completed',type=int,default=13)
 ap.add_argument('--modes',nargs='+',choices=MODES,default=list(MODES))
 ap.add_argument('--oracle-cases',type=int,default=100)
 ap.add_argument('--skip-oracle',action='store_true')
 ap.add_argument('--fresh',action='store_true',help='clear past checkpoints/results and start again')
 ap.add_argument('--retry-failed',action='store_true',help='retry previously failed configuration jobs')
 args=ap.parse_args()
 if args.runs<=0 or args.timeout<=0 or args.min_completed<=0 or 'st_only' not in args.modes:ap.error('invalid runs, timeout or modes; st_only mandatory')
 if len(set(args.datasets))!=len(args.datasets):ap.error('duplicate datasets')
 REPORT.parent.mkdir(parents=True,exist_ok=True)
 if args.fresh and CACHE.exists():CACHE.unlink()
 REPORT.write_text('',encoding='utf-8')
 log('# V62: original result trie, V61 fast emit, V62 tree-propagated closure mask, safe exact DFS fallback')
 log('# Release only, no phase clocks. Each block ST/start -> shuffled variants -> ST/end, with interpolated paired ST anchor.')
 log('# Paired speedups are compared within graph and block, then across graphs. Do not count incomplete datasets as wins.')
 log(f'[COMMAND] {sys.argv}')
 log(f'[CONFIG] 13data={args.datasets} modes={args.modes} runs={args.runs} timeout={args.timeout}s cpu={args.cpu} fresh={args.fresh}')
 log(f'[ENV] {platform.platform()} python={platform.python_version()} cwd={os.getcwd()}')
 try:
  s,h=resource.getrlimit(resource.RLIMIT_STACK)
  if s!=resource.RLIM_INFINITY and (h==resource.RLIM_INFINITY or s<h):
   resource.setrlimit(resource.RLIMIT_STACK,(min(64<<20,h) if h!=resource.RLIM_INFINITY else 64<<20,h))
 except Exception as e:log(f'[STACK_WARNING] {e}')
 allowed=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else []
 cpu=(allowed[0] if allowed and shutil.which('taskset') else None) if args.cpu=='auto' else (None if args.cpu=='none' else int(args.cpu))
 if cpu is not None and allowed and cpu not in allowed:ap.error(f'CPU {cpu} outside allowed {allowed}')
 log(f'[CPU_AFFINITY] {cpu}')
 exe,sha=build();log(f'[BUILD] release_sha256={sha} compile_flags={FLAGS}')
 store={'release_sha256':sha,'modes':args.modes,'datasets':{}}
 if CACHE.exists():
  old=json.loads(CACHE.read_text(encoding='utf-8'))
  if old.get('release_sha256')==sha and old.get('modes')==args.modes:
   store=old;log('[RESUME] loaded compatible checkpoint')
  else:
   log('[RESUME_WARNING] binary or mode set changed; old checkpoint preserved to .old.json; fresh timing is required')
   shutil.copyfile(CACHE,CACHE.with_suffix('.old.json'))
 persist(store)
 if not args.skip_oracle:
  log('[ORACLE_START] exact full sets for all V62 semantic modes and forced cap fallbacks')
  base.oracle(exe,args.oracle_cases,type('R',(),{'log':staticmethod(log)})(),28,512,args.timeout)
  log('[ORACLE_DONE] PASS')
 problems={};start_total=time.time()
 non_st=[m for m in args.modes if m!='st_only']
 for ds in args.datasets:
  source=filename(ds,args.data_root)
  if source is None:
   problems[ds]='dataset file not found';log(f'[MISSING] dataset={ds}');continue
  log(f'[START] dataset={ds} source={source}')
  try:
   with tempfile.TemporaryDirectory(prefix='v62_'+ds+'_') as tmp:
    prepared=Path(tmp)/'clean.txt'
    edges=base.cleanup_graph(source,prepared)
    digest=base.digest(prepared)
    log(f'[DATA] dataset={ds} clean_edges={edges} clean_sha256={digest}')
    dsentry=store['datasets'].get(ds,{})
    if dsentry.get('graph_sha256')!=digest:
     if dsentry:log(f'[RESET_GRAPH] dataset={ds} graph digest differs; invalidating prior timing')
     dsentry={'graph_sha256':digest,'blocks':{},'signature':None}
     store['datasets'][ds]=dsentry;persist(store)
    for rep in range(args.runs):
     block=dsentry['blocks'].setdefault(str(rep),{})
     # An interrupted block spans different thermal/load conditions. Keep
     # completed blocks but restart only the partial block on a new invocation.
     # Otherwise its two ST anchors would be temporally incomparable.
     if block and not has_complete(block,non_st):
      log(f'[RESUME_RESTART_PARTIAL_BLOCK] dataset={ds} block={rep+1}; discarding incomplete block for valid paired ST anchors')
      block.clear();persist(store)
     order=non_st.copy();random.Random(20261018+1009*rep+sum(map(ord,ds))).shuffle(order)
     jobs=['st_begin',*order,'st_end']
     st_failed=False
     for position,tag in enumerate(jobs):
      if tag in block and 'ms' in block[tag]:continue
      if tag in block and block[tag].get('error') and not args.retry_failed:
       log(f'[SKIP_FAILED_JOB] dataset={ds} block={rep+1} mode={tag} reason={block[tag]["error"]}')
       continue
      mode='st_only' if tag.startswith('st_') and tag in ('st_begin','st_end') else tag
      log(f'[JOB_START] dataset={ds} block={rep+1}/{args.runs} mode={tag} pos={position+1}/{len(jobs)}')
      try:
       info=base.execute(exe,prepared,mode,None,cpu,28,512,args.timeout)
       sig=[info['Count'],info['Checksum_XOR'],info['Checksum_SUM']]
       if dsentry['signature'] is None:dsentry['signature']=sig
       if sig != dsentry['signature']:raise ValueError(f'checksum mismatch {sig} != {dsentry["signature"]}')
       if ds in base.KNOWN_COUNT and sig[0]!=base.KNOWN_COUNT[ds]:raise ValueError(f'known COUNT mismatch {sig[0]} != {base.KNOWN_COUNT[ds]}')
       block[tag]={'ms':info['Search_Time_ms'],'clock':time.time(),'signature':sig,'rss_mib':info['rss_mib'],'bitmask_hits':info['V56_Hits'],'bitmask_outputs':info['V56_Outputs'],'prefork_skips':info['V56_PreFork_Skips']}
       del info
       log(f'[RUN] dataset={ds} block={rep+1}/{args.runs} mode={tag} search_ms={block[tag]["ms"]:.3f} hits={block[tag]["bitmask_hits"]} output={block[tag]["bitmask_outputs"]} prefork_skips={block[tag]["prefork_skips"]}')
      except Exception as e:
       block[tag]={'error':str(e)[-1000:]}
       log(f'[JOB_FAILED] dataset={ds} block={rep+1} mode={tag} reason={str(e)[-400:]}')
       persist(store)
       # Missing or failing ST baseline -> cannot compute any ratios in this block.
       if tag=='st_begin':
        st_failed=True
        break
      persist(store)
     if has_complete(block,non_st):
      ratios=paired_stats(block,non_st)
      log(f'[BLOCK_DONE] dataset={ds} block={rep+1} paired='+ ' '.join(f'{k}:{v:.4f}x' for k,v in ratios.items()))
     else:log(f'[BLOCK_PARTIAL] dataset={ds} block={rep+1} completed={sum("ms" in block.get(k,{}) for k in jobs)}/{len(jobs)}')
     if st_failed:
      problems[ds]='ST-only reference failed; subsequent blocks skipped';break
  except KeyboardInterrupt:
   log('[INTERRUPTED] safe checkpoint retained; run same command to resume');persist(store);raise
  except Exception as e:
   problems[ds]=str(e)[-800:];log(f'[FAILED_DATASET] dataset={ds} reason={str(e)[-500:]}')
  persist(store)
 done=report_summary(store,args,problems,sha)
 if done<args.min_completed:
  log(f'[INCOMPLETE] completed={done}, required={args.min_completed}; use same command to resume after resolving failures')
  raise SystemExit(2)
if __name__=='__main__':main()
