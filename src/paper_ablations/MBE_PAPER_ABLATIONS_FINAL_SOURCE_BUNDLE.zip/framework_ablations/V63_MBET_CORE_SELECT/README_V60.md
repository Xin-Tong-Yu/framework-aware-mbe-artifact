# Candidate Tree historical development notes

The variant at this revision retains the historical compiler switches. See the English overview in `V63_MBET_CORE_SELECT/README.md` and source-level mode flags for the exact option set.
