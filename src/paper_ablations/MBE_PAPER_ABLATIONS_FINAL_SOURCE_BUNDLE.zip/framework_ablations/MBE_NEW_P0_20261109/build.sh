#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
mkdir -p "$HERE/bin"
command -v g++ >/dev/null || { echo 'ERROR: g++ not found' >&2; exit 2; }
if [[ ! -f "$ROOT/MBE_CORRECTED_13DATA/two_source/ips.hpp" ]]; then
  echo 'ERROR: missing MBE_CORRECTED_13DATA/two_source/ips.hpp: install MBE_CORRECTED_13DATA before this package' >&2
  exit 2
fi
if [[ ! -x "$ROOT/MBE_FAST_FOUR_MODES/bin/one_core" ]]; then
  echo 'ERROR: missing original final single executable MBE_FAST_FOUR_MODES/bin/one_core; do NOT rebuild automatically' >&2
  exit 2
fi
# Source archived unchanged from 2024 author-provided MBET-master(2024icde).zip.
for m in mbet mbetm; do
  defs=(-D_MBET)
  [[ "$m" == mbetm ]] && defs+=(-DMBETM)
  echo "[BUILD] original_2024_$m"
  g++ -O3 -std=c++17 -UNDEBUG "${defs[@]}" -I "$HERE/original_mbet" "$HERE/original_mbet/main.cpp" -o "$HERE/bin/official_$m"
done
# Hold the SAME corrected explicit-enumeration IPS source, optimized flags,
# full-domain bitmap budget, and output hashing constant across all 4 cells.
SRC="$ROOT/MBE_CORRECTED_13DATA/two_source"
COMMON=(-O3 -std=c++17 -fopenmp -UNDEBUG -DIPS_BITMAP_BUDGET_MIB=512)
for storage in vector compact; do
  for terminal in st et_tg; do
    defs=("${COMMON[@]}")
    [[ "$storage" == compact ]] && defs+=(-DIPS_ST_V24_SINGLE_DEFECT)
    [[ "$terminal" == st ]] && defs+=(-DIPS_CLASSIC_PIVOT -DIPS_DISABLE_ET)
    echo "[BUILD] double_${storage}_${terminal}"
    g++ "${defs[@]}" -I "$SRC" "$SRC/main.cpp" -o "$HERE/bin/double_${storage}_${terminal}"
  done
done
printf '[BUILD_COMPLETE] %s\n' "$HERE/bin"
