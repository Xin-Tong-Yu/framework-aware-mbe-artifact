# Published Single and Double factorial campaigns

Single baseline comparison against original MBET and MBETM, and Double vector/compact crossed with ET/TG on/off. Run through `bash run_experiments.sh single-baseline ...` or `double-2x2 ...`. Confirm reporting contracts when citing baseline timings.

All run logs, timestamps, source hashes and dataset identifiers should be retained when reporting new measurements.
