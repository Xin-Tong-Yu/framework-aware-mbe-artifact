#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
if (( $# == 0 )) || [[ "$1" != single && "$1" != double ]]; then
  echo 'Usage: bash MBE_NEW_P0_20261109/run.sh single|double [--runs 5] [--timeout 1200] [--process-only youtube ...] [--skip-build]' >&2
  exit 2
fi
KIND="$1"; shift
exec python3 "$HERE/bench.py" --root "$ROOT" --kind "$KIND" "$@"
