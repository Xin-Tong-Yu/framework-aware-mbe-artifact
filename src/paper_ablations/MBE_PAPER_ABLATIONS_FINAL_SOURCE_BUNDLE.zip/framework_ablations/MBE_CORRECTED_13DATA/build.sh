#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$HERE/bin"
COMMON=(-O3 -std=c++17 -fopenmp -UNDEBUG -DIPS_ST_V24_SINGLE_DEFECT -DIPS_BITMAP_BUDGET_MIB=512)
for mode in two_st two_et two_et_tg_compact; do
  flags=("${COMMON[@]}")
  if [[ "$mode" == two_st ]]; then flags+=(-DIPS_CLASSIC_PIVOT -DIPS_DISABLE_ET); fi
  if [[ "$mode" == two_et ]]; then flags+=(-DIPS_CLASSIC_PIVOT); fi
  echo "[BUILD] $mode bounded full-domain bitmaps"
  g++ "${flags[@]}" -I "$HERE/two_source" "$HERE/two_source/main.cpp" -o "$HERE/bin/${mode}_safe"
done
printf '[COMPLETE] Safe IPS experiments: %s/bin/*_safe\n' "$HERE"
