#!/usr/bin/env python3
"""Safely isolate the previously-failing datasets before starting a 5-block run."""
import argparse
import datetime
from pathlib import Path
import sys
from bench import execute, parse_run
from prepare_corrected import prepare_corrected
from known_counts import KNOWN_COUNT


def main():
    ap=argparse.ArgumentParser(description='Untimed preflight: correct graph header, then one ST and bounded-memory IPS ST')
    ap.add_argument('--project-root',type=Path,default=Path.cwd())
    ap.add_argument('--datasets',nargs='+',default=['bibsonomy','dblp'])
    ap.add_argument('--ips-memory-mib',type=int,default=6144)
    ap.add_argument('--timeout',type=int,default=1200)
    args=ap.parse_args()
    root=args.project_root.resolve()
    here=Path(__file__).resolve().parent
    (here/'logs').mkdir(parents=True,exist_ok=True)
    log_path=here/'logs'/('PREFLIGHT_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.txt')
    def log(s):
        print(s,flush=True)
        with log_path.open('a',encoding='utf8') as f:f.write(s+'\n')
    if args.ips_memory_mib<1024:ap.error('min memory cap = 1024 MiB')
    for ds in args.datasets:
        if ds not in KNOWN_COUNT:ap.error('unknown graph '+ds)
        p=root/'data_clean'/(ds+'.txt')
        one=here/'.cache'/(ds+'.one.txt')
        two=here/'.cache'/(ds+'.two.clean')
        log('[DATASET] '+ds)
        try:
            info=prepare_corrected(p,one,two,here/'.cache'/(ds+'.meta.json'))
            log('[PREP] edges=%s header_skipped=%s'%(info['edges'],info['header_skipped']))
        except Exception as e:
            log('[PREP_FAIL] '+repr(e));continue
        out=[]
        for mode in ['one_st','two_st']:
            if mode=='one_st':
                cmd=['bash',str(root/'MBE_FAST_FOUR_MODES'/'run.sh'),'one_st',str(one)]
                cap=None
            else:
                cmd=[str(here/'bin'/'two_st_safe'),'-f',str(two),'-d','two']
                cap=args.ips_memory_mib
            log('[RUN_START] '+mode)
            rc,stdout,stderr,wall,error=execute(cmd,args.timeout,None,root,cap)
            try:
                if error:raise RuntimeError(error)
                if rc!=0:raise RuntimeError('rc='+str(rc)+' stderr_tail='+stderr[-1000:])
                x=parse_run(mode,stdout,wall)
                if x['count']!=KNOWN_COUNT[ds]:raise ValueError(f'EXPECTED_COUNT_MISMATCH {x["count"]} != {KNOWN_COUNT[ds]}')
                log('[PASS] %s count=%d ms=%s rss_kb=%s wall_s=%.2f'%(mode,x['count'],x['ms'], __import__('re').search(r'BENCH_PEAK_RSS_KB=(\d+)',stderr).group(1) if 'BENCH_PEAK_RSS_KB=' in stderr else '?',wall))
                out.append(x)
            except Exception as e:
                log('[FAIL] '+mode+' '+repr(e));break
        if len(out)==2:log('[GRAPH_OK] '+ds+' correct header, both STs match known Count')
        else:log('[GRAPH_NOT_READY] '+ds+' do NOT include in formal six-mode table yet')
    log('[REPORT] '+str(log_path))


if __name__=='__main__':main()
