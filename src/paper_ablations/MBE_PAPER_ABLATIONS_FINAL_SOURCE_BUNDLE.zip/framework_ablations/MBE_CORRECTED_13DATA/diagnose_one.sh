#!/usr/bin/env bash
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ $# -ne 1 ]]; then echo 'Usage: bash diagnose_one.sh PATH_TO_DATA_CLEAN_BIBSONOMY_TXT' >&2; exit 2; fi
INPUT="$1"
[[ -f "$INPUT" ]] || { echo "No input: $INPUT" >&2;exit 2; }
EXE="$HERE/build_one_asan/mbet_fast"
[[ -x "$EXE" ]] || { echo "First run: bash $HERE/build_one_asan.sh" >&2;exit 2; }
mkdir -p "$HERE/logs"
LOG="$HERE/logs/one_bibsonomy_$(date +%Y%m%d_%H%M%S).txt"
{
 echo "[DIAGNOSTIC_ONLY] Unmodified one-sided source plus ASAN/UBSAN, not official timed executable"
 echo "[INPUT] $INPUT"
 # No aggressive memory cap with ASan, which reserves huge virtual address space.
 ASAN_OPTIONS='detect_leaks=0:halt_on_error=1:abort_on_error=1' \
 UBSAN_OPTIONS='print_stacktrace=1:halt_on_error=1' \
 /usr/bin/time -v timeout --signal=TERM --kill-after=5s 300 \
  "$EXE" -f "$INPUT" --st on -l 1 -r 1 --orientation auto-size \
  --et off --tg off --kappa 1 --v56-terminal 0 --v56-prefork off \
  --et-root-summary on --et-cardinality-gate on \
  --tg-prefix-cap 8 --tg-two-min-family 8 \
  --v56-min-paths 5 --v56-max-paths 32 --v56-max-cols 128 \
  --v56-max-bits 12 --v56-component-cap 10
 echo "[EXIT_CODE] $?"
} 2>&1 | tee "$LOG"
exit "${PIPESTATUS[0]}"
