#!/usr/bin/env python3
"""Prepare exact SAME simple edge list for both enumerators, discarding a 3-integer header.

The legacy runner erroneously passed the original 3-integer header as an edge to
both enumerators, causing all 13 result counts to be exactly +1.
"""
from pathlib import Path
import hashlib
import json
import os
import tempfile


def sha256(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def prepare_corrected(source,one_out,two_out,meta_out):
    source=Path(source);one_out=Path(one_out);two_out=Path(two_out);meta_out=Path(meta_out)
    hash_source=sha256(source)
    if meta_out.exists() and one_out.exists() and two_out.exists():
        try:
            meta=json.loads(meta_out.read_text())
            if meta.get('source_sha256')==hash_source and meta.get('one_sha256')==sha256(one_out) and meta.get('two_sha256')==sha256(two_out):
                print(f'[PREP_REUSE_CORRECT] {source.name} edges={meta["edges"]}',flush=True)
                return meta
        except (ValueError, KeyError, OSError):pass
    one_out.parent.mkdir(parents=True,exist_ok=True)
    two_out.parent.mkdir(parents=True,exist_ok=True)
    tmp1=one_out.with_suffix(one_out.suffix+'.tmp')
    tmp2=two_out.with_suffix(two_out.suffix+'.tmp')
    head=None;seen=0
    try:
        with source.open('r',encoding='utf-8-sig') as rd, tmp1.open('w',encoding='ascii') as one, tmp2.open('w',encoding='ascii') as two:
            for ln,raw in enumerate(rd,1):
                line=raw.strip()
                if not line or line.startswith(('#','%')):continue
                v=line.split()
                if head is None:
                    if len(v)!=3:raise ValueError(f'{source} first data line must contain a three-integer header, got {line[:150]}')
                    n1,n2,m=map(int,v)
                    if n1<1 or n2<1 or m<1:raise ValueError('Invalid graph header counts')
                    head=(n1,n2,m)
                    two.write(f'{n1} {n2} {m}\n')
                    continue
                if len(v)!=2:raise ValueError(f'{source}: expected 2 integers at line {ln}: {line[:150]}')
                a,b=map(int,v)
                if a<0 or b<0 or a>=head[0] or b>=head[1]:
                    raise ValueError(f'{source}: edge endpoints {(a,b)} outside declared header bounds {head[:2]} at line {ln}')
                one.write(f'{a} {b}\n')
                two.write(f'{a} {b}\n')
                seen+=1
        if head is None or seen!=head[2]:raise ValueError(f'{source}: header reports {head[2] if head else None} edges but read {seen}')
        os.replace(tmp1,one_out);os.replace(tmp2,two_out)
        meta=dict(source_sha256=hash_source,one_sha256=sha256(one_out),two_sha256=sha256(two_out),
                  n_left=head[0],n_right=head[1],edges=seen,header_skipped=True)
        meta_out.write_text(json.dumps(meta,indent=2),encoding='utf8')
        print(f'[PREP_CORRECT] {source.name}: n1={head[0]} n2={head[1]} m={seen}; header SKIPPED, 0 spurious edges',flush=True)
        return meta
    finally:
        tmp1.unlink(missing_ok=True)
        tmp2.unlink(missing_ok=True)
