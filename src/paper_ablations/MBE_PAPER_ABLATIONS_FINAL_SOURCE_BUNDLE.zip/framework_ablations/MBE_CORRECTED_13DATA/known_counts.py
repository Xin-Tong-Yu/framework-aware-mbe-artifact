# Counts already verified by the older header-aware 13-data MBET experiment.
KNOWN_COUNT = dict(youtube=1826587,actors=1075444,stackoverflow=3320824,
    bibsonomy=2507269,dblp=4899032,forum=16261,ukwiki=23772,escorts=49538,
    github=55346398,bkcrossing=54458953,twitter=5536526,imdb=5160061,amazon=7551358)
