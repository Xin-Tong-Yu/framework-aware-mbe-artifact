# Header-aware thirteen-graph ST/ET/TG campaign

Six-mode Single/Double benchmark with a validated three-integer input header, explicit fingerprint processing and guarded Double bitmap allocation. Run `bash MBE_CORRECTED_13DATA/build.sh` then `bash MBE_CORRECTED_13DATA/run.sh --runs 5 --timeout 1200 --skip-build`. Historical 6 GiB virtual address limit applies as configured by its own runner.

All run logs, timestamps, source hashes and dataset identifiers should be retained when reporting new measurements.
