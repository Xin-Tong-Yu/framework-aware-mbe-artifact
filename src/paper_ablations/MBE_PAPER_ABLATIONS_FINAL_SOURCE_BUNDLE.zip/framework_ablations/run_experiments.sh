#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
ulimit -s 262144 || { echo '[ERROR] Could not set 256 MiB recursion stack' >&2; exit 1; }
usage() {
  cat <<'EOF'
MBE paper experiment suite: all result-producing modules are independent.
Usage: bash run_experiments.sh COMMAND [ORIGINAL_RUNNER_OPTIONS]

COMMAND:
  setup-data [SOURCE_DIR]      Connect existing 13 input graphs without copying them
  check-source                Check required source files and installed tools
  build-core                  Build optimized Single/Double engines and both P0 baselines
  oracle [N=20]               Full-set correctness comparison on N random small graphs
  candidate [OPTIONS]         Single Candidate Tree / fork cursor / pre-fork ablation
  result-cr [OPTIONS]         Single Result Tree x Compressed Reporting (2x2)
  six-mode [OPTIONS]          Corrected Single/Double ST, ET, ET+TG on all 13 graphs
  single-baseline [OPTIONS]   Final Single vs original published MBET/MBETM
  double-2x2 [OPTIONS]        Explicit enumeration Vector/Compact x ET/TG
  ips-native-ablation [OPTIONS] Count-aggregation IPS state ablation (separate protocol)
  ips-native-baseline [OPTIONS] Published IPS vs count-aggregation state variant

All 13-graph runners default to 5 repetitions in their own original code.
For the four most relevant runs, use:
  bash run_experiments.sh single-baseline --runs 5 --timeout 1200 --skip-build
  bash run_experiments.sh double-2x2 --runs 5 --timeout 1200 --skip-build
  bash run_experiments.sh six-mode --runs 5 --timeout 1200 --skip-build
  bash run_experiments.sh result-cr --runs 5 --timeout 1200 --skip-build

Never use --fresh unless deliberately discarding a backed-up checkpoint.
Do not run multiple performance campaigns at the same time.
Do not compare raw IPS count-aggregation timings with explicit-enumeration timings.
EOF
}
cmd="${1:-help}"; if (($#)); then shift; fi
case "$cmd" in
 help|-h|--help)usage;;
 setup-data) bash "$HERE/setup_data.sh" "$@";;
 check-source) python3 "$HERE/check_sources.py";;
 build-core)
  python3 "$HERE/check_sources.py"
  bash "$HERE/MBE_FAST_FOUR_MODES/build.sh"
  bash "$HERE/MBE_CORRECTED_13DATA/build.sh"
  bash "$HERE/MBE_NEW_P0_20261109/build.sh"
  ;;
 oracle)
  n="${1:-20}"
  [[ "$n" =~ ^[0-9]+$ ]] || { echo '[ERROR] oracle count must be integer' >&2; exit 2; }
  python3 "$HERE/MBE_FAST_FOUR_MODES/verify_full.py" --cases "$n" --seed 196002
  ;;
 candidate)
  [[ -d "$HERE/data_clean" ]] || { echo '[ERROR] Run setup-data first' >&2; exit 2; }
  bash "$HERE/V63_MBET_CORE_SELECT/run.sh" "$@";;
 result-cr)
  [[ -d "$HERE/data_clean" ]] || { echo '[ERROR] Run setup-data first' >&2; exit 2; }
  bash "$HERE/MBE_ST_CR_2X2_20261108/run.sh" "$@";;
 six-mode)
  [[ -d "$HERE/data_clean" ]] || { echo '[ERROR] Run setup-data first' >&2; exit 2; }
  bash "$HERE/MBE_CORRECTED_13DATA/run.sh" "$@";;
 single-baseline)
  [[ -d "$HERE/data_clean" ]] || { echo '[ERROR] Run setup-data first' >&2; exit 2; }
  bash "$HERE/MBE_NEW_P0_20261109/run.sh" single "$@";;
 double-2x2)
  [[ -d "$HERE/data_clean" ]] || { echo '[ERROR] Run setup-data first' >&2; exit 2; }
  bash "$HERE/MBE_NEW_P0_20261109/run.sh" double "$@";;
 ips-native-ablation)
  [[ -d "$HERE/data_clean" ]] || { echo '[ERROR] Run setup-data first' >&2; exit 2; }
  bash "$HERE/IPS_ST_ABLATION_13DATA/run_ablation.sh" "$@";;
 ips-native-baseline)
  [[ -d "$HERE/data_clean" ]] || { echo '[ERROR] Run setup-data first' >&2; exit 2; }
  bash "$HERE/IPS_ST_13DATA_2026/run_13.sh" "$@";;
 *) echo "[ERROR] Unknown command: $cmd" >&2;usage; exit 2;;
esac
