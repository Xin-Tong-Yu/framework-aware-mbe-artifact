#ifndef MAXIMAL_H
#define MAXIMAL_H

#include "graph.hpp"
#include "array.hpp"
#include <chrono>

class IPS_t {

private:
    BiGraph_t *g;
    int32_t lrs[2] = {0, 0}, realRSize[2] = {0, 0};
    uint64_t totalMaximalCount = 0, et = 0, zt = 0, tot = 0;
    std::vector<std::vector<int32_t>> ws;
    XCArray_t S[2];

    std::string od;
    std::chrono::time_point<std::chrono::steady_clock> t0;

    /*
     * ndC: record a vertex's (in C + X from one side) #non-neighbors in C (of the opposite side)
     * ndX: record a vertex's (in C from one side) #non-neighbors in X (of the opposite side)
     * nN:  record a vertex's (in C from one side) non-neighbors in C (of the opposite side)
     */
    std::vector<int32_t> ndC[2], ndX[2];
    std::vector<std::vector<int32_t>> nN[2];

    void increment(uint64_t val) {
        auto t1 = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0);

        uint64_t new_val = totalMaximalCount + val;
        if (new_val / 1000000 != totalMaximalCount / 1000000) {
            printf("Maximal_BiClique_Count: %lu, Time: %lu ms\n", new_val, duration.count());
        }
        totalMaximalCount = new_val;
    }

    void branch(int32_t deep) {

        if (S[0].cSize() + realRSize[0] < lrs[0] || S[1].cSize() + realRSize[1] < lrs[1] ||
                (S[0].cSize() + realRSize[0]) * (S[1].cSize() + realRSize[1]) < lrs[0] * lrs[1]) return;

        if (S[0].CIsEmpty() && S[1].CIsEmpty()) {
            if (S[0].XIsEmpty() && S[1].XIsEmpty()) {
                if (realRSize[0] >= lrs[0] && realRSize[1] >= lrs[1])
                    increment(1);
            }
            return;
        }

        tot++;

        /*
         * Initialization:
         * (1) Initialize ndC of (C + X) from one side as cSize of the opposite side
         * (2) Initialize ndX of C from one side as xSide of the opposite side
         */

        for (int32_t t = 0; t < 2; t++) {
            int32_t z = t ^ 1;

            for (int32_t i = S[t].x; i < S[t].c; i++) {
                int32_t u = S[t][i];
                ndC[t][u] = S[z].cSize();
            }

            for (int32_t i = S[t].c; i < S[t].r; i++) {
                int32_t u = S[t][i];

                ndC[t][u] = S[z].cSize();
                ndX[t][u] = S[z].xSize();
                nN[t][u].clear();

            }
        }

//        /*
//         * Update ndC and ndX (iteration over one side is enough):
//         * U: --|---X---|---C---|--
//         * V: --|---X---|---C---|--
//         * (1) When one iterator belongs to U.X; use another iterator over V.C
//         * (2) When one iterator belongs to U.C; use another iterator over V.(C+X)
//         */
        int32_t e = 0, tt = 0, zz = 1;

        for (int32_t i = S[tt].x; i < S[tt].r; i++) {
            int32_t u = S[tt][i];

            if (i < S[tt].c) {       // u belongs to X

                // v belongs to C only
                if (g->deg(u, tt) >= S[zz].cSize()) {
                    for (int32_t j = S[zz].c; j < S[zz].r; j++) {
                        int32_t v = S[zz][j];
                        if (g->connect(u, v, tt)) {
                            ndC[tt][u]--;
                            ndX[zz][v]--;
                        }
                    }
                } else {
                    for (int32_t j = g->p[tt][u]; j < g->p[tt][u + 1]; j++) {
                        int32_t v = g->e[tt][j];
                        int32_t pv = S[zz].pos(v);
                        if (S[zz].c <= pv && pv < S[zz].r) {
                            ndC[tt][u]--;
                            ndX[zz][v]--;
                        }
                    }
                }
            } else {                  // u belongs to C

                // v belongs to X
                if (g->deg(u, tt) >= S[zz].xSize()) {
                    for (int32_t j = S[zz].x; j < S[zz].c; j++) {
                        int32_t v = S[zz][j];
                        if (g->connect(u, v, tt)) {
                            ndX[tt][u]--;
                            ndC[zz][v]--;
                        }
                    }
                } else {
                    for (int32_t j = g->p[tt][u]; j < g->p[tt][u + 1]; j++) {
                        int32_t v = g->e[tt][j];
                        int32_t pv = S[zz].pos(v);
                        if (S[zz].x <= pv && pv < S[zz].c) {
                            ndX[tt][u]--;
                            ndC[zz][v]--;
                        }
                    }
                }

                // v belongs to C
                if (g->deg(u, tt) >= S[zz].cSize() - 1) {    // "cSize()-k" means u is *possible* to be skipped
                    for (int32_t j = S[zz].c; j < S[zz].r; j++) {
                        int32_t v = S[zz][j];
                        if (g->connect(u, v, tt)) {
                            e++;
                            ndC[tt][u]--;
                            ndC[zz][v]--;
                        } else {
                            nN[tt][u].push_back(v);
                            nN[zz][v].push_back(u);
                        }
                    }
                } else {        // u must not be skipped
                    for (int32_t j = g->p[tt][u]; j < g->p[tt][u + 1]; j++) {
                        int32_t v = g->e[tt][j];
                        int32_t pv = S[zz].pos(v);
                        if (S[zz].c <= pv && pv < S[zz].r) {
                            e++;
                            ndC[tt][u]--;
                            ndC[zz][v]--;
                        }
                    }
                }
            }
        }

        //when there is no edge
        if (e == 0) {
            zt++;

            auto tryAddZSide = [&](int32_t t) {
                int32_t z = t ^ 1;
                bool canZAdd = true;

                //add the vertices in z side, the X in z side must be empty
                if (!S[z].XIsEmpty() || realRSize[t] == 0 || realRSize[t] < lrs[t]) return;

                //if a vertex in X and t side is connected to all vertices in z side C
                for (int32_t i = S[t].x; i < S[t].c; i++) {
                    int32_t u = S[t][i];

                    if (ndC[t][u] == 0) {
                        canZAdd = false;
                        break;
                    }

                }

                if (canZAdd && realRSize[z] + S[z].cSize() >= lrs[z]) {
                    increment(1);
                }
            };

            if (!S[0].CIsEmpty() && !S[1].CIsEmpty()) {
                tryAddZSide(0);
                tryAddZSide(1);
            } else if (S[0].CIsEmpty()) {
                tryAddZSide(0);
            } else if (S[1].CIsEmpty()) {
                tryAddZSide(1);
            }

            return;
        }

        if (S[0].XIsEmpty() && S[1].XIsEmpty()) {
            bool terminate = true;
            int32_t f_size[2] = {0, 0}, p_size[2] = {0, 0};

            for (int32_t t = 0; t < 2; t++) {
                for (int32_t i = S[t].c; i < S[t].r; i++) {
                    int32_t u = S[t][i];

                    if (ndC[t][u] == 0) {
                        f_size[t]++;
                    } else if (ndC[t][u] == 1) {
                        p_size[t]++;
                    } else {
                        terminate = false;
                        break;
                    }
                }

                if (!terminate) break;
            }

            if (terminate) {
                et++;

                auto Comb = [&](int32_t n, int32_t m) {
                    uint64_t res = 1;

                    for (int32_t i = 0; i < std::min(m, n - m); i++) {
                        res *= (n - i);
                        res /= (i + 1);
                    }

                    return res;
                };

                for (int32_t i = 0; i <= p_size[0]; i++) {
                    int32_t j = p_size[0] - i;
                    if (realRSize[0] + f_size[0] + i >= lrs[0] && realRSize[1] + f_size[1] + j >= lrs[1]) {
                        increment(Comb(p_size[0], i));
                    }
                }

                return;
            }
        }

        /*
         * Choose pivot from X first; then C
         */
        int32_t min_side, min_ndC = INT32_MAX, min_pos, min_id;

        for (int32_t t = 0; t < 2; t++) {
            for (int32_t i = S[t].x; i < S[t].c; i++) {
                int32_t u = S[t][i];

                if (ndC[t][u] < min_ndC) {
                    min_side = t;
                    min_ndC = ndC[t][u];
                    min_pos = i;
                    min_id = u;
                }
            }
        }

        for (int32_t t = 0; t < 2; t++) {
            int32_t z = t ^ 1;

            for (int32_t i = S[t].c; i < S[t].r; i++) {
                int32_t u = S[t][i];

                if (ndC[t][u] < min_ndC) {
                    bool isPivot = false;

                    if (ndC[t][u] > 1 || ndX[t][u] > 0) isPivot = true;
                    else {
                        for (int v : nN[t][u]) {
                            if (ndC[z][v] > 1) {
                                isPivot = true;
                                break;
                            }
                        }
                    }

                    if (isPivot) {
                        min_side = t;
                        min_ndC = ndC[t][u];
                        min_pos = i;
                        min_id = u;
                    }
                }
            }
        }

        /*
         * t is the side of pivot, z is the opposite side
         */
        int32_t t = min_side, z = min_side ^ 1, pivot = min_id;
        bool isPivotInX = (S[t].x <= min_pos && min_pos < S[t].c);

        int32_t x[2];
        int32_t c[2];
        int32_t r[2];
        x[t] = S[t].x;
        x[z] = S[z].x;
        c[t] = S[t].c;
        c[z] = S[z].c;
        r[t] = S[t].r;
        r[z] = S[z].r;

        if (g->deg(pivot, t) > S[z].r - S[z].c) {
            if (S[z].r > 0) {
                for (int32_t i = S[z].r - 1; i >= S[z].c; i--) {
                    if (!g->connect(pivot, S[z][i], t)) {
                        S[z].swapByPos(--S[z].r, i);
                    }

                    if (i == 0) break;
                }
            }
        } else {
            int32_t u = pivot;
            int32_t tmpR = S[z].c;
            for (int32_t j = g->p[t][u]; j < g->p[t][u + 1]; j++) {
                int32_t v = g->e[t][j];
                int32_t pv = S[z].pos(v);
                if (S[z].c <= pv && pv < S[z].r) {
                    S[z].swapByPos(tmpR++, pv);
                }
            }
            S[z].r = tmpR;
        }

        int32_t wsSize = r[z] - S[z].r;
        if (ws[deep].size() < wsSize) {
            ws[deep].resize(wsSize * 2);
        }
        memcpy(ws[deep].data(), S[z].begin() + S[z].r, sizeof(int32_t) * wsSize);

        //put the pivot at the first of R

        if (!isPivotInX) {
            realRSize[t]++;

            S[t].swapByPos(min_pos, --r[t]);
            S[t].r = r[t];

            if (g->deg(pivot, t) > S[z].c - S[z].x) {
                for (int32_t i = S[z].x; i < S[z].c; i++) {
                    if (!g->connect(pivot, S[z][i], t)) {
                        S[z].swapByPos(S[z].x++, i);
                    }
                }
            } else {
                int32_t u = pivot;
                int32_t tmpX = S[z].c;
                for (int32_t j = g->p[t][u]; j < g->p[t][u + 1]; j++) {
                    int32_t v = g->e[t][j];
                    int32_t pv = S[z].pos(v);
                    if (S[z].x <= pv && pv < S[z].c) {
                        S[z].swapByPos(--tmpX, pv);
                    }
                }
                S[z].x = tmpX;
            }

            branch(deep + 1);

            //put pivot into X, child branches do not change R
            S[t].swapByPos(c[t]++, r[t]++);
            realRSize[t]--;
        }

        for (int32_t i = 0; i < wsSize; i++) {

            int32_t w = ws[deep][i];
            realRSize[z]++;
            S[z].swapByPos(S[z].pos(w), --r[z]);

            //initial next level parameter
            S[t].x = x[t];
            S[z].x = x[z];
            S[t].c = c[t];
            S[z].c = c[z];
            S[t].r = r[t];
            S[z].r = r[z];

            if (g->deg(w, z) > S[t].c - S[t].x) {
                for (int32_t j = S[t].x; j < S[t].c; j++) {
                    if (!g->connect(w, S[t][j], z)) {
                        S[t].swapByPos(S[t].x++, j);
                    }
                }
            } else {
                int32_t tmpX = S[t].c;
                for (int32_t j = g->p[z][w]; j < g->p[z][w + 1]; j++) {
                    int32_t u = g->e[z][j];
                    int32_t pu = S[t].pos(u);
                    if (S[t].x <= pu && pu < S[t].c) {
                        S[t].swapByPos(--tmpX, pu);
                    }
                }
                S[t].x = tmpX;
            }

            if (g->deg(w, z) > S[t].c - S[t].r) {
                if (S[t].r > 0) {
                    for (int32_t j = S[t].r - 1; j >= S[t].c; j--) {
                        if (!g->connect(w, S[t][j], z)) {
                            S[t].swapByPos(--S[t].r, j);
                        }

                        if (j == 0) break;
                    }
                }
            } else {
                int32_t tmpR = S[t].c;
                for (int32_t j = g->p[z][w]; j < g->p[z][w + 1]; j++) {
                    int32_t u = g->e[z][j];
                    int32_t pu = S[t].pos(u);
                    if (S[t].c <= pu && pu < S[t].r) {
                        S[t].swapByPos(tmpR++, pu);
                    }
                }
                S[t].r = tmpR;
            }

            branch(deep + 1);

            S[z].swapByPos(c[z]++, r[z]++);

            realRSize[z]--;
        }

        for (int32_t i = 0; i < wsSize; i++) {
            int32_t w = ws[deep][i];
            S[z].swapByPos(S[z].pos(w), --c[z]);
        }

        //put pivot back into C
        if (!isPivotInX) {
            S[t].swapByPos(S[t].pos(pivot), --c[t]);
        }

    }

public:
    IPS_t(const std::string & fPath, const std::string & order, int32_t ls, int32_t rs) {

        lrs[0] = std::max(1, ls);
        lrs[1] = std::max(1, rs);

        g = new BiGraph_t(fPath, order, lrs[0], lrs[1]);
        od = order;

        S[0].resize(g->n[0]);
        S[1].resize(g->n[1]);
        ndC[0].resize(g->n[0]);
        ndX[0].resize(g->n[0]);
        ndC[1].resize(g->n[1]);
        ndX[1].resize(g->n[1]);

        nN[0].resize(g->n[0]);
        nN[1].resize(g->n[1]);

        ws.resize(g->maxDu + g->maxDv);
        realRSize[0] = 0;
        realRSize[1] = 0;
    }

    void run() {
        t0 = std::chrono::steady_clock::now();

        int32_t t = 0, z = 1;

        if (od == "core") {
            if (g->maxDu < g->maxDv) {
                t = 1;
                z = 0;
            }
        }
        else if (od == "two") {
            if (g->core[0] < g->core[1]) {
                t = 1;
                z = 0;
            }
        }

        std::vector<int32_t> d[2];
        d[0].resize(g->n[0]);
        d[1].resize(g->n[1]);
        std::vector<int32_t> id(std::max(g->n[0], g->n[1]));
        std::vector<int32_t> keys(std::max(g->n[0], g->n[1]));
        for (int32_t u = 0; u < std::max(g->n[0], g->n[1]); u++) id[u] = u;
        std::vector<int32_t> buffer[2];
        buffer[0].resize(g->n[0]);
        buffer[1].resize(g->n[1]);

        int32_t maxDTmp[2];
        uint32_t gamma = 0;

        for(int32_t u = 0; u < g->n[t]; u++) {

            if (u % 10000 == 0) printf("Finish %.2f%% (%d / %d)\n", (double) (u + 0.) / g->n[t] * 100, u, g->n[t]);

            S[t].c = S[t].r = g->n[t];
            S[z].c = S[z].r = g->n[z];
            realRSize[t] = 1;
            realRSize[z] = 0;

            buffer[t].clear(); buffer[z].clear();

            for(int32_t i = g->p[t][u]; i < g->p[t][u + 1]; i++) {
                int32_t v = g->e[t][i];

                S[z].swapByPos(--S[z].c, S[z].pos(v));
            }

            maxDTmp[0] = maxDTmp[1] = 0;
            for(int32_t i = g->p[t][u]; i < g->p[t][u + 1]; i++) {
                int32_t v = g->e[t][i];

                if(g->p[z][v + 1] > 0)
                    for(int32_t j = g->p[z][v + 1] - 1; j >= g->p[z][v]; j--) {
                        int32_t w = g->e[z][j];

                        if(w > u) {
                            int32_t pw = S[t].pos(w);
                            if(pw < S[t].c) {
                                S[t].swapByPos(--S[t].c, pw);
                            }

                            d[t][w]++;
                            d[z][v]++;
                            maxDTmp[t] = std::max(maxDTmp[t], d[t][w]);
                            maxDTmp[z] = std::max(maxDTmp[z], d[z][v]);
                        }
                        else break;

                        if(j == 0) break;
                    }
            }

            Heap_t zheap(S[z].r - S[z].c, maxDTmp[z] + 1), theap(S[t].r - S[t].c, maxDTmp[t] + 1);
            for(int32_t i = S[z].c; i < S[z].r; i++) keys[i - S[z].c] = d[z][S[z][i]] + 1;
            for(int32_t i = S[z].c; i < S[z].r; i++) buffer[z].push_back(S[z][i]);
            zheap.init(S[z].r - S[z].c, maxDTmp[z] + 1, id.data(), keys.data());

            for(int32_t i = S[t].c; i < S[t].r; i++) keys[i - S[t].c] = d[t][S[t][i]] + 1;
            for(int32_t i = S[t].c; i < S[t].r; i++) buffer[t].push_back(S[t][i]);
            theap.init(S[t].r - S[t].c, maxDTmp[t] + 1, id.data(), keys.data());

            for(int32_t i = S[z].c; i < S[z].r; i++) d[z][S[z][i]] = 0;
            for(int32_t i = S[t].c; i < S[t].r; i++) d[t][S[t][i]] = 0;

            while(true) {
                int32_t v, degree = 0;
                bool updated = false;

                while(zheap.get_min(v, degree) && degree < lrs[t]) {
                    zheap.pop_min(v, degree);

                    for(int32_t i = S[t].c; i < S[t].r; i++) {
                        if(g->connect(S[z][v + S[z].c], S[t][i], z)) {
                            theap.decrement(i - S[t].c);
                            updated = true;
                        }
                    }
                }
                while(theap.get_min(v, degree) && degree < lrs[z]) {
                    theap.pop_min(v, degree);

                    for(int32_t i = S[z].c; i < S[z].r; i++) {
                        if(g->connect(S[t][v + S[t].c], S[z][i], t)) {
                            zheap.decrement(i - S[z].c);
                            updated = true;
                        }
                    }
                }

                if(!updated) {
                    S[t].c = S[t].r;
                    S[z].c = S[z].r;
                    while(!zheap.empty()) {
                        zheap.pop_min(v, degree);
                        S[z].swapByPos(--S[z].c, S[z].pos(buffer[z][v]));
                    }
                    while(!theap.empty()) {
                        theap.pop_min(v, degree);
                        S[t].swapByPos(--S[t].c, S[t].pos(buffer[t][v]));
                    }
                    break;
                }
            }

            S[z].x = S[z].c;
            S[t].x = S[t].c;

            for(int32_t i = g->p[t][u]; i < g->p[t][u + 1]; i++) {
                int32_t v = g->e[t][i];
                if(g->p[z][v + 1] > 0)
                    for(int32_t j = g->p[z][v]; j < g->p[z][v + 1]; j++) {
                        int32_t w = g->e[z][j];

                        if(w < u) {
                            int32_t pw = S[t].pos(w);
                            if(pw < S[t].x) {
                                S[t].swapByPos(--S[t].x, pw);
                            }
                        }
                        else break;

                        if(j == 0) break;
                    }
            }

            uint32_t sz = S[t].cSize() + S[z].cSize() + S[t].xSize() + S[z].xSize();
            gamma = gamma > sz ? gamma : sz;

            branch(0);
        }

        auto t1 = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0);

        printf("|L| = %d, |R| = %d, |E| = %d, MaxDeg = %d, gamma = %d\n", g->n[0], g->n[1], g->m, std::max(g->maxDu, g->maxDv), gamma);
        printf("Maximal_BiClique_Count: %lu, Time: %lu ms\n", totalMaximalCount, duration.count());
        printf("ET / TT = %lu / %lu (%.2lf%%)\n", et, tot, 100. * ((double) et / (double) tot));
        printf("ZT / TT = %lu / %lu (%.2lf%%)\n", zt, tot, 100. * ((double) zt / (double) tot));
    }

};

#endif
