# Maximal Biclique Enumeration with Improved Worst-Case Time Complexity Guarantee: A Partition-Oriented Strategy

This repository contains the codes and a technical report for maximal biclique enumeration with a new enumeration framework. 

## Setup

To run the codes correctly, please ensure you have installed `cmake (minimum version 3.6)` on your computer or server since we need to use cmake to generate `Makefile` to compile our codes. There are two steps to run our codes. The first step is a pre-processing procedure, which is to ensure that the graph contains no duplicate edges. The second step is the main listing procedure, which enumerates all maximal bicliques. 

## Step 0 - Compile the codes

When you already download the codes, run the following commands to compile our codes. 

```bash
cd src/
mkdir build && cd build/
cmake .. && make
```

After running the codes, there will be an executable files called `ips`, which means you have already compiled our codes. 

## Step 1 - Pre-processing Procedure

When the dataset is prepared, the file may have some comments at the very beginning, please ensure those comments are deleted before running the codes. The file should have $m + 1$ lines, where the first line has three numbers, i.e., $|L|$, $|R|$ and $|E|$, representing the number of vertices on the left side, the number of vertices on the right side and the number of edges in the bipartite graph $G=(L\cup R, E)$. From the second line, each line has two numbers, represent the endpoints of an edge. In the [github](https://github.com/wangkaixin219/IPS/blob/main/dataset/github.clean) dataset provided in this repo, we already cleaned the data following the rule stated above. 

## Step 2 - Enumeration Procedure

To enumerate maximal bicliques in the graph, we need to specify (1) the datasets, (2) the ordering of the vertices and (3) user-specified parameter. Therefore, the running command is: 

```bash
./ips -f PATH_TO_DATASET -d V_ORDER (-l NUM -r NUM)
```

The parameter after `-f` is the path to the graph file. The parameter after `-d` is the ordering of the vertices. To make it well-align with the paper, we provide two possible orderings. One is the degeneracy ordering, which we use `core` to represent. The other is the unilateral ordering, which we use `two` to represent. We also provide two optional parameters `-l` and `-r` to determine the lower bound the returned maximal bicliques. 

For example, to enumerate all maximal bicliques, 

```bash
./ips -f ../../dataset/github.clean -d two      # enumerate all maximal biclique using the unilateral ordering
./ips -f ../../dataset/github.clean -d core     # enumerate all maximal biclique using the degeneracy ordering
```

To enumerate all maximal biclique with $|L|\ge 11$ and $|R|\ge 11$, 

```
./ips -f ../../dataset/github.clean -d two -l 11 -r 11      # enumerate all maximal biclique using the unilateral ordering with its size at least (11, 11)
./ips -f ../../dataset/github.clean -d core -l 11 -r 11     # enumerate all maximal biclique using the degeneracy ordering with its size at least (11, 11)
```
