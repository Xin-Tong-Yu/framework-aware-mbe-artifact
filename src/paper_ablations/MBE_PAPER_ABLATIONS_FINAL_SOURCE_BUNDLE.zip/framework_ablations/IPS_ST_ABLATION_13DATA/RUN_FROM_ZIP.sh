#!/usr/bin/env bash
set -euo pipefail
ZIP="${1:-IPS_ST_ABLATION_13DATA.zip}"
shift || true
ROOT="$PWD"
PKG=IPS_ST_ABLATION_13DATA
if [[ ! -f "$ZIP" ]]; then
  echo "ZIP not found: $ZIP" >&2
  exit 1
fi
unzip -q -o "$ZIP" "$PKG/*" -d "$ROOT"
exec bash "$ROOT/$PKG/run_ablation.sh" "$@"
