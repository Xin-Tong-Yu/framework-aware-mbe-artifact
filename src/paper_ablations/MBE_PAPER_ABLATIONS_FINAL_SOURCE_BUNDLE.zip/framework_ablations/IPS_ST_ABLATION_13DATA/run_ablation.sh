#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(pwd)"
exec python3 "$PKG_DIR/run_ips_ablation.py" --project-root "$PROJECT_ROOT" "$@"
