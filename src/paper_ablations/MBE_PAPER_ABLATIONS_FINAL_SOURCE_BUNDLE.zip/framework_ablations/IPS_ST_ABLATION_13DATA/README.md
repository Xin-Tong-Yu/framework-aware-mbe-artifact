# Native IPS state and adjacency controls

Four native IPS configurations: official source, adjacency hybrid only, compact defect state only, and both. All use native IPS counting semantics. Run `bash run_experiments.sh ips-native-ablation --runs 5 --timeout 1200`.

All run logs, timestamps, source hashes and dataset identifiers should be retained when reporting new measurements.
