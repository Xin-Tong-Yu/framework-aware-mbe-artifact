#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="${1:-$HERE/../data_clean}"
SRC="$(realpath "$SRC")"
DST="$HERE/data_clean"
if [[ ! -d "$SRC" ]]; then
  echo "[ERROR] Dataset directory not found: $SRC" >&2
  echo "Usage: bash setup_data.sh /path/to/data_clean" >&2
  exit 2
fi
if [[ -L "$DST" ]]; then
  actual="$(readlink -f "$DST")"
  if [[ "$actual" == "$SRC" ]]; then
    echo "[DATA_OK] existing link: $DST -> $SRC"
  else
    echo "[ERROR] Existing link points elsewhere: $DST -> $actual" >&2
    exit 2
  fi
elif [[ -e "$DST" ]]; then
  echo "[ERROR] Existing data_clean is not a symbolic link. No files will be overwritten: $DST" >&2
  exit 2
else
  ln -s "$SRC" "$DST"
  echo "[DATA_OK] linked $DST -> $SRC"
fi
missing=0
for d in youtube actors stackoverflow bibsonomy dblp forum ukwiki escorts github bkcrossing twitter imdb amazon; do
  if [[ ! -f "$DST/$d.txt" ]]; then
    echo "[MISSING] $d.txt" >&2
    missing=$((missing+1))
  fi
done
if ((missing)); then echo "[ERROR] $missing datasets missing" >&2; exit 3; fi
python3 - "$DST" <<'PY2'
import sys,pathlib
p=pathlib.Path(sys.argv[1])
for f in sorted(p.glob('*.txt')):
  if f.stem not in {'youtube','actors','stackoverflow','bibsonomy','dblp','forum','ukwiki','escorts','github','bkcrossing','twitter','imdb','amazon'}: continue
  with f.open(encoding='utf8',errors='replace') as h:
    head=next((line.strip() for line in h if line.strip() and not line.startswith('#')), '')
  parts=head.split()
  if len(parts)!=3 or not all(x.lstrip('+-').isdigit() for x in parts):
    print('[HEADER_WARNING] expected 3-integer header, found:',f.name,repr(head))
  else: print('[DATA_HEADER] '+f.name+': '+head)
print('[DATA_READY] No graph file was modified.')
PY2
