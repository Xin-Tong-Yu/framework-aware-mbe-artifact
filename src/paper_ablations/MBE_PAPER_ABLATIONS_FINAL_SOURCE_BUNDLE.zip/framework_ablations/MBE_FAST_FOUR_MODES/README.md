# Explicit enumeration core

Single prefix-tree and Double partition-based sources with switchable state layout, early termination and termination guidance. Run `bash MBE_FAST_FOUR_MODES/build.sh`, `bash MBE_FAST_FOUR_MODES/smoke.sh`, and `python3 MBE_FAST_FOUR_MODES/verify_full.py --cases 30`.

All run logs, timestamps, source hashes and dataset identifiers should be retained when reporting new measurements.
