#!/usr/bin/env python3
"""V57 small-defect bitmask ET output/trigger benchmark: one durable result artifact (V57_ALL_RESULTS.txt)."""
import argparse
import hashlib
import math
import os
import platform
import random
import re
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from verify_oracle import oracle_set, parse_emitted

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
BINARY_MODES = {
 'st_only': '--et off --tg off --kappa 1 --v56-terminal 0 --v56-prefork off'.split(),
 'd_prefork': '--et off --tg off --kappa 1 --v56-terminal 0 --v56-prefork on'.split(),
 'et2_only': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on'.split(),
 'b_ref': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3'.split(),
 'b_direct': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v57-mask-direct on'.split(),
 'b_prefix': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v57-mask-prefix on'.split(),
 'b_fast': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v57-mask-fast-closure on'.split(),
 'b_prefix_fast': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v57-mask-prefix on --v57-mask-fast-closure on'.split(),
 'b_adaptive8': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v56-min-paths 8 --v57-mask-prefix on --v57-mask-fast-closure on'.split(),
 'b_adaptive12': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v56-min-paths 12 --v57-mask-prefix on --v57-mask-fast-closure on'.split(),
 'b_adaptive8_d': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v56-min-paths 8 --v57-mask-prefix on --v57-mask-fast-closure on --v56-prefork on'.split(),
 'b_output2': '--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v57-mask-prefix on --v57-mask-fast-closure on --v57-mask-output-factor 2'.split(),
 'et2_oldtg': '--et on --tg on --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --tg-prefix-min 3 --tg-batch-mode skip'.split(),
 'b_adaptive8_tg2': '--et on --tg on --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on --v56-terminal 3 --v56-min-paths 8 --v57-mask-prefix on --v57-mask-fast-closure on --tg2-prefix on --tg-prefix-min 4 --tg-min-family 16 --tg-batch-mode skip'.split(),
}

COMPILER = ['-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_FLAGS_RELEASE=-O3 -UNDEBUG',
            '-DMBE_ET_STREAM=ON','-DMBE_V32_CANDIDATE_POOL=ON','-DMBE_V32_RESULT_POOL=ON',
            '-DMBE_V31_RESULT_HOT=OFF','-DMBE_V31_FORK_PATH=OFF',
            '-DMBE_V40_FLAT_RESULT=ON','-DMBE_V40_FLAT_CANDIDATE=OFF',
            '-DMBE_V42_INLINE_RESULT=ON','-DMBE_V42_FAST_REPORT=ON',
            '-DMBE_V52_INLINE_FORK_SCRATCH=ON']
COMMON = ('--st on -l 1 -r 1 --orientation auto-size '
          '--et-root-summary on --et-cardinality-gate on '
          '--tg-prefix-cap 8 --tg-two-min-family 8 --v56-min-paths 5 --v56-max-paths 32 --v56-max-cols 128 --v56-max-bits 12 --v56-component-cap 10').split()
KNOWN_COUNT = dict(youtube=1826587,actors=1075444,stackoverflow=3320824,bibsonomy=2507269,
                   dblp=4899032,forum=16261,ukwiki=23772,escorts=49538,github=55346398,
                   bkcrossing=54458953,twitter=5536526,imdb=5160061,amazon=7551358)

class Report:
 def __init__(self,p):
  self.p=p; p.parent.mkdir(parents=True,exist_ok=True);p.write_text('',encoding='utf8')
 def log(self,s=''):
  print(s,flush=True)
  with self.p.open('a',encoding='utf8') as f:f.write(s+'\n')

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
 return h.hexdigest()

def build(diag,rep):
 dest=HERE/('build_v57_diag' if diag else 'build_v57_release')
 cmd=['cmake','-S',str(HERE/'source'),'-B',str(dest),*COMPILER,
      '-DMBE_ET13_DIAG='+('ON' if diag else 'OFF')]
 for c in [cmd,['cmake','--build',str(dest),'--parallel','2']]:
  p=subprocess.run(c,text=True,capture_output=True,timeout=360)
  if p.returncode:
   raise RuntimeError('build failed: '+str(c)+'\n'+p.stdout[-4000:]+'\n'+p.stderr[-4000:])
 exe=dest/'mbet_fast'
 rep.log(f'[BUILD] {"diagnostic" if diag else "timing"} SHA256={digest(exe)}')
 return exe

def cleanup_graph(src,dst):
 seenheader=False;first=True;cnt=0
 with src.open('r',encoding='utf-8-sig') as ins,dst.open('w',encoding='ascii') as out:
  for line in ins:
   s=line.strip()
   if not s or s.startswith(('#','%')):continue
   vals=s.split()
   if first and len(vals)==3:
    header=list(map(int,vals));seenheader=True;first=False;continue
   first=False
   if len(vals)!=2:raise ValueError(f'invalid edge line: {s[:100]}')
   a,b=map(int,vals)
   if a<0 or b<0:raise ValueError('negative vertex ID')
   out.write(f'{a}\t{b}\n');cnt+=1
 if seenheader and header[2]!=cnt:raise ValueError('header edge-count mismatch')
 if cnt==0:raise ValueError('empty graph')
 return cnt

def execute(exe,data,mode,rep,cpuid,limit_edges,limit_mis,timeout,extra=()):
 cmd=[str(exe),'-f',str(data),*COMMON,*BINARY_MODES[mode],
      '--et2-max-defects',str(limit_edges),'--et2-max-mis',str(limit_mis),*extra]
 if cpuid is not None:cmd=['taskset','-c',str(cpuid),*cmd]
 if shutil.which('/usr/bin/time'):cmd=['/usr/bin/time','-f','V57_RSS_KB=%M',*cmd]
 started=time.perf_counter()
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
 wall=time.perf_counter()-started
 if p.returncode:raise RuntimeError(f'run failed mode={mode}, cmd={cmd}: {p.stderr[-1500:]}')
 def field(name):
  match=re.search(r'^'+re.escape(name)+r':\s*(\S+)',p.stdout,re.M)
  if match is None:raise RuntimeError(f'missing {name} from {mode}: {p.stdout[-1500:]}')
  return match.group(1)
 keys=('Count','Checksum_XOR','Checksum_SUM','Search_Time_ms','ET_Hits','ET2_Attempts',
       'ET2_Verified','ET2_Hits','ET2_Nonmatching_Hits','ET2_Fallback_Shape',
       'ET2_Fallback_Degree','ET2_Fallback_Cap','ET2_MIS_Generated',
       'TG_Prefix_Ge3_Hits','TG_Deferred_Paths','ET2_Root_Gate_Rejections',
       'ET2_Trie_Reuse_Batches','ET2_Trie_Reused_Columns','ET2_Scratch_Reused_Calls',
       'V56_Attempts','V56_Shape_Checked','V56_Hits','V56_Outputs',
       'V56_Cap_Rejections','V56_PreFork_Skips','V56_Pivot_Branches',
       'TG2_Plan_Attempts','TG2_Candidate_Prefixes','TG2_Prefix_Hits',
       'TG2_Nonmatching_Hits','TG2_Deferred_Paths','TG2_MIS_Outputs',
       'TG2_Cap_Rejections','TG2_Emit_New','TG2_Emit_Duplicate',
       'V57_Mask_Closed','V57_Mask_Candidates','V57_Mask_Output_Rejections',
       'V57_Mask_Direct_Outputs','V57_Mask_Reused_Columns')
 info={k:(float(field(k)) if k=='Search_Time_ms' else int(field(k))) for k in keys}
 info['wall_s']=wall
 rss=re.search(r'V57_RSS_KB=(\d+)',p.stderr)
 info['rss_mib']=float(rss.group(1))/1024 if rss else None
 info['stdout']=p.stdout
 return info

def oracle(exe,count,rep,edges_cap,mis_cap,timeout):
 rng=random.Random(20261017)
 tests=0;fallback_tests=0
 with tempfile.TemporaryDirectory(prefix='v57_oracle_') as t:
  f=Path(t)/'g.txt'
  fixtures=[]
  # Alternating missing pairs: complement includes even cycles and paths.
  for n in (3,4,5,6,7,8):
   fixtures.append([(r,c) for r in range(n) for c in range(n+1) if c == n or c not in (r,(r+1)%n)])
  for n in (4,5,6,7):
   fixtures.append([(r,c) for r in range(n) for c in range(n+1) if c==n or (r!=0 or c>=4)])
  for iteration in range(count+len(fixtures)):
   if iteration<len(fixtures):edges=fixtures[iteration]
   else:
    l=rng.randint(2,8);r=rng.randint(2,8);p=rng.uniform(.03,.98)
    edges=[(a,b) for a in range(l) for b in range(r) if rng.random()<p] or [(0,0)]
   f.write_text(''.join(f'{a}\t{b}\n' for a,b in edges));expect=oracle_set(edges)
   orientation='left-upper' if iteration%2 else 'right-upper'
   for mode in BINARY_MODES:
    params=['--emit','stdout','--orientation',orientation,'--et-min-paths','2']
    got=execute(exe,f,mode,rep,None,edges_cap,mis_cap,min(timeout,30),params)
    answers=parse_emitted(got['stdout'])
    if len(answers)!=len(expect) or set(answers)!=expect:
     raise RuntimeError(f'ORACLE MISMATCH case={iteration} mode={mode} orient={orientation} '
                        f'expected={expect}, actual={answers}')
    tests+=1
   if iteration%10==0:
    # Force MIS-cap fallback and verify no partial trie writes.
    got=execute(exe,f,'b_ref',rep,None,1,1,min(timeout,30),
                ['--emit','stdout','--orientation',orientation,'--et-min-paths','2'])
    if set(parse_emitted(got['stdout']))!=expect:raise RuntimeError('MIS CAP fallback mismatch')
    fallback_tests+=1
 rep.log(f'[ORACLE] PASS cases={count+len(fixtures)} full_set_comparisons={tests} forced_cap_fallback={fallback_tests}')

def main():
 parser=argparse.ArgumentParser(description='V57: output-aware bitmask ET, prefix reuse and adaptive A/B')
 parser.add_argument('--datasets',nargs='+',default=['youtube'])
 parser.add_argument('--data-root',type=Path,default=None)
 parser.add_argument('--runs',type=int,default=3)
 parser.add_argument('--oracle-cases',type=int,default=100)
 parser.add_argument('--cpu',default='auto',help='auto, none or a number permitted by CPU affinity')
 parser.add_argument('--timeout',type=int,default=900)
 parser.add_argument('--et2-max-defects',type=int,default=28)
 parser.add_argument('--et2-max-mis',type=int,default=512)
 parser.add_argument('--skip-work-profile',action='store_true')
 parser.add_argument('--skip-oracle',action='store_true')
 parser.add_argument('--modes',nargs='+',choices=BINARY_MODES,default=list(BINARY_MODES))
 args=parser.parse_args()
 if args.runs<1 or args.oracle_cases<0 or not 1<=args.et2_max_defects<=30 or not 1<=args.et2_max_mis<=65536:parser.error('invalid counts/caps')
 if len(set(args.datasets))!=len(args.datasets):parser.error('duplicate datasets')
 if 'st_only' not in args.modes:parser.error('--modes must include st_only for correctness baseline')
 report=Report(PROJECT/'diagnostics'/'V57_ALL_RESULTS.txt')
 report.log('# V57 MBET | adaptive bitmask ET, direct emission, prefix reuse, epoch-stamped closure | single report')
 report.log('# V56 B is exact AND-closure. V57 preserves closure/ownership; compares output pipelines and trigger thresholds.')
 report.log('# D is independent conservative proven-empty Fork preflight; no virtual Fork implementation claimed.')
 report.log('# TG2 comparator reuses V55 canonical-prefix logic; no new TG algorithm is claimed.')
 report.log('# Output-factor policies decide before Result Tree mutation; fallback always ordinary MBET.')
 report.log('# Search_Time_ms excludes input loading and preprocessing. All speedups are empirical.')
 report.log(f'COMMAND={" ".join(sys.argv)}')
 report.log(f'ENV={platform.platform()} python={platform.python_version()} cwd={os.getcwd()}')
 report.log(f'BUILD_FLAGS={COMPILER}')
 allowed=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else []
 cpu=allowed[0] if args.cpu=='auto' and allowed and shutil.which('taskset') else (None if args.cpu in ('auto','none') else int(args.cpu))
 if cpu is not None and allowed and cpu not in allowed:raise ValueError(f'CPU {cpu} not permitted: {allowed}')
 report.log(f'CPU_AFFINITY={cpu if cpu is not None else "none"} runs={args.runs} oracle_cases={args.oracle_cases} et2_caps=({args.et2_max_defects},{args.et2_max_mis})')
 report.log(f'MODES={args.modes} datasets={args.datasets}')
 try:
  exe=build(False,report)
  if not args.skip_oracle:oracle(exe,args.oracle_cases,report,args.et2_max_defects,args.et2_max_mis,args.timeout)
  with tempfile.TemporaryDirectory(prefix='v57_data_') as t:
   clean={}
   for ds in args.datasets:
    src=(args.data_root/ds).with_suffix('.txt') if args.data_root is not None else PROJECT/'data_clean'/f'{ds}.txt'
    if not src.exists():src=HERE/'data'/f'{ds}.txt'
    if not src.exists():raise FileNotFoundError(f'dataset {ds}: not found at data-root, project/data_clean or ZIP/data')
    target=Path(t)/f'{ds}.txt'
    n=cleanup_graph(src,target);clean[ds]=target
    report.log(f'[DATA] {ds} input={src} edges={n} sha256={digest(target)}')
   work={}
   if not args.skip_work_profile:
    diag=build(True,report)
    for ds in args.datasets:
     for mode in args.modes:
      if mode not in args.modes:continue
      info=execute(diag,clean[ds],mode,report,cpu,args.et2_max_defects,args.et2_max_mis,args.timeout)
      m=re.search(r'^\[V51\](.*)$',info['stdout'],re.M)
      if m is None:raise RuntimeError('diagnostic binary omitted [V51]')
      attrs=dict((x,int(y)) for x,y in re.findall(r'(\w+)=(\d+)',m.group(1)))
      work[ds,mode]=attrs
      report.log(f'[WORK] {ds} {mode} find={attrs["find"]} fork={attrs["fork"]} '
                 f'fork_nodes={attrs["fork_nodes_created"]} dfs_find={attrs["dfs_find"]} result_queries={attrs["result_child_ensure"]} '
                 f'et2_hits={info["ET2_Hits"]} v56_hits={info["V56_Hits"]} v56_outputs={info["V56_Outputs"]} d_prefork_skips={info["V56_PreFork_Skips"]} tg2_hits={info["TG2_Prefix_Hits"]} '
                 f'v57_mask_closed={info["V57_Mask_Closed"]} v57_masks={info["V57_Mask_Candidates"]} '
                 f'v57_output_reject={info["V57_Mask_Output_Rejections"]} '
                 f'v57_prefix_cols={info["V57_Mask_Reused_Columns"]} '
                 f'(instrumentation time EXCLUDED from benchmarks)')
    # These four variants are implementation-only transformations of exactly
    # the same V56 B closure, so Find/Fork/DFS and created trie nodes must match.
    # Trie lookup count deliberately may differ.
    for ds in args.datasets:
     ref=work.get((ds,'b_ref'))
     if ref is None:continue
     keys=('find','fork','fork_nodes_created','dfs_find','result_nodes_created')
     for mode in ('b_direct','b_prefix','b_fast','b_prefix_fast'):
      other=work.get((ds,mode))
      if other is None:continue
      for key in keys:
       if ref[key]!=other[key]:
        raise RuntimeError(f'WORK_EQUIVALENCE FAIL {ds} {mode} {key}: {ref[key]} vs {other[key]}')
      report.log(f'[WORK_EQUIVALENCE] PASS dataset={ds} b_ref_vs={mode} '
                 f'result_queries_saved={ref["result_child_ensure"]-other["result_child_ensure"]}')
   # Full outputs are checked by exact Oracle and signatures, across all variants.
   jobs=[(rep,ds,mode) for rep in range(args.runs) for ds in args.datasets for mode in args.modes]
   random.Random(20261017).shuffle(jobs)
   rows=[]; expected={}
   for rep,ds,mode in jobs:
    info=execute(exe,clean[ds],mode,report,cpu,args.et2_max_defects,args.et2_max_mis,args.timeout)
    sig=(info['Count'],info['Checksum_XOR'],info['Checksum_SUM'])
    if ds in expected and expected[ds]!=sig:raise RuntimeError(f'CHECKSUM MISMATCH {ds} {mode} {sig}!={expected[ds]}')
    expected[ds]=sig
    if ds in KNOWN_COUNT and sig[0]!=KNOWN_COUNT[ds]:raise RuntimeError(f'EXPECTED COUNT MISMATCH {ds}: {sig[0]} vs {KNOWN_COUNT[ds]}')
    rows.append((ds,mode,info['Search_Time_ms'],info))
    report.log(f'[RUN] dataset={ds} rep={rep+1}/{args.runs} mode={mode} search_ms={info["Search_Time_ms"]:.3f} '
               f'wall_s={info["wall_s"]:.3f} rss_mib={info["rss_mib"]} '
               f'et_hits={info["ET_Hits"]} et2_hits={info["ET2_Hits"]} v56_attempts={info["V56_Attempts"]} v56_hits={info["V56_Hits"]} v56_outputs={info["V56_Outputs"]} v56_cap_reject={info["V56_Cap_Rejections"]} d_prefork_skips={info["V56_PreFork_Skips"]} '
               f'v57_closed={info["V57_Mask_Closed"]} v57_output_reject={info["V57_Mask_Output_Rejections"]} '
               f'v57_prefix_cols={info["V57_Mask_Reused_Columns"]} '
               f'et2_cap_fallback={info["ET2_Fallback_Cap"]} trie_batches={info["ET2_Trie_Reuse_Batches"]} tg_prefix_hits={info["TG_Prefix_Ge3_Hits"]} tg2_hits={info["TG2_Prefix_Hits"]} tg2_nonmatching={info["TG2_Nonmatching_Hits"]} tg2_outputs={info["TG2_MIS_Outputs"]} tg2_cap_rejections={info["TG2_Cap_Rejections"]}')
   report.log('\n=== SUMMARY: MEDIAN SEARCH TIME ===')
   speeds={mode:[] for mode in args.modes};wins={mode:0 for mode in args.modes}
   for ds in args.datasets:
    sig=expected[ds]
    report.log(f'[CHECKSUM] {ds} count={sig[0]} xor={sig[1]} sum={sig[2]} PASS')
    med={mode:statistics.median(ms for d,m,ms,_ in rows if d==ds and m==mode) for mode in args.modes}
    st=med['st_only']
    for mode in args.modes:
     speed=st/med[mode];speeds[mode].append(speed);wins[mode]+=speed>1
     report.log(f'[MEDIAN] dataset={ds} mode={mode} search_ms={med[mode]:.3f} speedup_vs_ST={speed:.5f}x')
    for mode in args.modes:
     if (ds,'st_only') in work and (ds,mode) in work:
      a,b=work[ds,'st_only'],work[ds,mode]
      report.log(f'[WORK_DELTA] dataset={ds} mode={mode} fork_saved={a["fork"]-b["fork"]} '
                 f'dfs_find_saved={a["dfs_find"]-b["dfs_find"]} '
                 f'candidate_nodes_saved={a["fork_nodes_created"]-b["fork_nodes_created"]} '
                 f'result_queries_saved={a["result_child_ensure"]-b["result_child_ensure"]}')
   for mode in args.modes:
    gm=math.exp(sum(math.log(v) for v in speeds[mode])/len(speeds[mode]))
    report.log(f'[GM] mode={mode} datasets={len(speeds[mode])} speedup_vs_ST={gm:.5f}x wins={wins[mode]}/{len(speeds[mode])}')
   report.log('[COMPLETE] yes; output is one report file; see warnings about limited data and run-to-run variance.')
 except BaseException as exc:
  report.log(f'[FAILED] {type(exc).__name__}: {exc}')
  raise
 finally:
  report.log(f'[OUTPUT] {report.p}')

if __name__=='__main__':main()
