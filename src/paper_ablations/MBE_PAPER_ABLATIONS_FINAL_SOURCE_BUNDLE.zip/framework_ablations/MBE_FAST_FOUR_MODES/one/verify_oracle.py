def oracle_set(edges):
    L={a for a,b in edges}; R={b for a,b in edges}
    adj={a:{b for aa,b in edges if aa==a} for a in L};verts=sorted(L);ans=set()
    for mask in range(1,1<<len(verts)):
        chosen=[verts[i] for i in range(len(verts)) if mask&(1<<i)]
        right=set.intersection(*(adj[a] for a in chosen))
        if not right:continue
        left={a for a in L if right.issubset(adj[a])}
        if left:ans.add((tuple(sorted(left)),tuple(sorted(right))))
    return ans

def parse_emitted(out):
    import re
    ans=[]
    for line in out.splitlines():
        m=re.fullmatch(r'\s*\[([0-9, ]*)\]\s*\[([0-9, ]*)\]\s*',line)
        if not m:continue
        def side(s):return tuple(sorted(map(int,[v.strip() for v in s.split(',') if v.strip()])))
        ans.append((side(m.group(1)),side(m.group(2))))
    return ans
