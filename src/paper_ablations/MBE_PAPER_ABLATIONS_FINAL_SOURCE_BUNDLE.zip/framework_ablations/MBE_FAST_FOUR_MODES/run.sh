#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if (($# < 2)); then
 echo 'Usage: bash run.sh one_st|one_st_d|one_st_inline|one_et|one_et_d|one_et_tg|one_et_tg_d|two_st|two_st_hybrid|two_et|two_et_tg|two_et_tg_compact GRAPH [EXTRA_NATIVE_ARGS...]' >&2
 exit 2
fi
MODE="$1"; GRAPH="$2"; shift 2
[[ -f "$GRAPH" ]] || { echo "Graph does not exist: $GRAPH" >&2; exit 2; }
case "$MODE" in
 one_st|one_st_d|one_st_inline|one_et|one_et_d|one_et_tg|one_et_tg_d)
  EXE="$HERE/bin/one_core"
  [[ "$MODE" == one_st_inline ]] && EXE="$HERE/bin/one_inline"
  if [[ ! -x "$EXE" ]]; then bash "$HERE/build.sh"; fi
  # Preserve exact V63 release flags: the work is part of the engine's normal search.
  COMMON=(--st on -l 1 -r 1 --orientation auto-size --et-root-summary on --et-cardinality-gate on \
   --tg-prefix-cap 8 --tg-two-min-family 8 --v56-min-paths 5 --v56-max-paths 32 \
   --v56-max-cols 128 --v56-max-bits 12 --v56-component-cap 10)
  ET=(--et on --tg off --kappa 2 --et2-root-degree-gate on --et2-reuse-buffers on \
   --v56-terminal 3 --v57-mask-prefix on --v57-mask-fast-closure on \
   --v56-min-paths 8 --v59-dispatch 1 --v59-work-gate 96 \
   --v60-lazy-mask on --v60-root-gate on --v62-tree-mask on \
   --v62-mask-cursor on --v61-fast-emit on)
  if [[ "$MODE" == one_st || "$MODE" == one_st_d || "$MODE" == one_st_inline ]]; then
   ARGS=(--et off --tg off --kappa 1 --v56-terminal 0 --v56-prefork off)
  elif [[ "$MODE" == one_et ]]; then
   ARGS=("${ET[@]}")
  else
   # Real TG2: bounded canonical prefix with deferred exact matching resolver.
   # The TG setting is independent of V63 Core's performance certificate.
   ARGS=("${ET[@]}" --tg on --tg2-prefix on --tg-prefix-min 4 --tg-min-family 16 --tg-batch-mode skip)
  fi
  if [[ "$MODE" == one_st_d || "$MODE" == one_et_d || "$MODE" == one_et_tg_d ]]; then
   ARGS+=(--v56-prefork on)
  fi
  INPUT="$GRAPH"
  if [[ "$GRAPH" == *.clean ]]; then
    mkdir -p "$HERE/.cache"
    INPUT="$HERE/.cache/$(basename "$GRAPH").one.txt"
    if [[ ! -f "$INPUT" || "$GRAPH" -nt "$INPUT" ]]; then tail -n +2 "$GRAPH" > "$INPUT"; fi
  fi
  echo "[MODE] $MODE; one-sided V63, ST=on ET=$([[ "$MODE" == one_*et* ]] && echo on || echo off) TG=$([[ "$MODE" == one_et_tg* ]] && echo on || echo off)"
  exec "$EXE" -f "$INPUT" "${COMMON[@]}" "${ARGS[@]}" "$@"
  ;;
 two_st|two_st_hybrid|two_et|two_et_tg|two_et_tg_compact)
  EXE="$HERE/bin/$MODE"
  if [[ ! -x "$EXE" ]]; then bash "$HERE/build.sh"; fi
  if [[ ! -x "$EXE" ]]; then
   echo '[MISSING_BUILD] Run bash MBE_FAST_FOUR_MODES/build.sh' >&2; exit 4
  fi
  if [[ "$GRAPH" == *.clean ]]; then INPUT="$GRAPH"; else
   INPUT="$HERE/.cache/$(basename "$GRAPH").v25.clean"
   mkdir -p "$HERE/.cache"
   python3 "$HERE/prepare_two.py" "$GRAPH" "$INPUT"
  fi
  case "$MODE" in two_st_hybrid) echo '[MODE] two_st_hybrid IPS-v25 ST=on ET=off TG=off; hybrid adjacency';;
   two_et_tg_compact) echo '[MODE] two_et_tg_compact IPS-v25 ST=on ET=on TG=on; compact-only adjacency';;
   two_st) echo '[MODE] two_st IPS-v25 ST=on ET=off TG=off';;
   two_et) echo '[MODE] two_et IPS-v25 ST=on ET=on TG=off';;
   two_et_tg) echo '[MODE] two_et_tg IPS-v25 ST=on ET=on TG=on';;
  esac
  exec "$EXE" -f "$INPUT" -d two "$@"
  ;;
 *) echo "Unknown mode $MODE" >&2;exit 2;;
esac
