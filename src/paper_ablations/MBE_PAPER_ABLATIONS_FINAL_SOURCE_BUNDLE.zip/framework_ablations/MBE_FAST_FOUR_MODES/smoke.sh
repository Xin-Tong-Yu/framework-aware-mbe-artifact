#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$HERE/.cache"
SAMPLE="$HERE/.cache/smoke_edges.txt"
printf '0 0\n0 1\n1 1\n1 2\n2 0\n2 2\n' > "$SAMPLE"
for mode in one_st one_et one_et_tg two_st two_st_hybrid two_et two_et_tg two_et_tg_compact; do
 echo "[SMOKE] $mode"
 bash "$HERE/run.sh" "$mode" "$SAMPLE" | grep -E '^(Count|Checksum_XOR|Checksum_SUM|TG2_Prefix_Enabled|Variant:|ST:|ET:|TG:|Maximal_BiClique_Count:|Enumeration_Set_XOR:|Enumeration_Set_SUM:)' || true
done
echo '[SMOKE_COMPLETE] Compare one-side count/fingerprints and two-side count/fingerprints separately.'
