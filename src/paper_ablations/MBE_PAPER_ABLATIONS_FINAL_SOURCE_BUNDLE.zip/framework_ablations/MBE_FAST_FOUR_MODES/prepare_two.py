#!/usr/bin/env python3
"""Exact bipartite ID compaction for .txt edge lists; v25 .clean already has L R E header."""
import sys, pathlib, os, tempfile
p=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);out.parent.mkdir(parents=True,exist_ok=True)
if out.exists() and out.stat().st_mtime>=p.stat().st_mtime:
 print('[PREP_REUSE]',out,file=sys.stderr);sys.exit(0)
L={};R={};E=set()
with p.open(encoding='utf-8-sig') as f:
 for ln,line in enumerate(f,1):
  line=line.strip()
  if not line or line.startswith('#') or line.startswith('%'):continue
  sp=line.split()
  if len(sp)<2:continue
  try:a,b=int(sp[0]),int(sp[1])
  except ValueError:continue
  if a<0 or b<0:raise ValueError(f'negative vertex id at line {ln}')
  if a not in L:L[a]=len(L)
  if b not in R:R[b]=len(R)
  E.add((L[a],R[b]))
with tempfile.NamedTemporaryFile(mode='w',dir=out.parent,delete=False) as w:
 tmp=w.name
 w.write(f'{len(L)} {len(R)} {len(E)}\n')
 for a,b in sorted(E):w.write(f'{a} {b}\n')
os.replace(tmp,out)
print(f'[PREP] {len(L)} {len(R)} {len(E)} -> {out}',file=sys.stderr)
