#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$HERE/bin"
command -v cmake >/dev/null || { echo 'Please install cmake' >&2; exit 2; }
command -v g++ >/dev/null || { echo 'Please install g++' >&2; exit 2; }
ONE_COMMON=(
  -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_FLAGS_RELEASE='-O3 -UNDEBUG'
  -DMBE_ET_STREAM=ON -DMBE_V32_CANDIDATE_POOL=ON -DMBE_V32_RESULT_POOL=ON
  -DMBE_V31_RESULT_HOT=OFF -DMBE_V31_FORK_PATH=OFF
  -DMBE_V40_FLAT_RESULT=ON -DMBE_V40_FLAT_CANDIDATE=OFF
  -DMBE_V42_INLINE_RESULT=ON -DMBE_V42_FAST_REPORT=ON
  -DMBE_V52_INLINE_FORK_SCRATCH=ON -DMBE_V61_FAST_RESULT_APPEND=OFF
  -DMBE_ET13_DIAG=OFF -DMBE_V58_COST_PROFILE=OFF
  -DMBE_V63_INLINE_CANDIDATE=ON
)
for variant in core inline; do
  if [[ "$variant" == core ]]; then SKIP=ON; else SKIP=OFF; fi
  echo "[ONE_BUILD] $variant (Candidate Inline=ON, Fork Cursor Skip=$SKIP)"
  cmake -S "$HERE/one/source" -B "$HERE/build_one_$variant" \
     "${ONE_COMMON[@]}" -DMBE_V30_SKIP_EMPTY_PREV="$SKIP" >/dev/null
  cmake --build "$HERE/build_one_$variant" --parallel 2 >/dev/null
  ln -sfn "../build_one_$variant/mbet_fast" "$HERE/bin/one_$variant"
done
SRC="$HERE/two/source"
[[ -f "$SRC/ips.hpp" && -f "$SRC/main.cpp" ]] || { echo '[FATAL] v25 enumerator source absent' >&2; exit 3; }
grep -q 'enumerateMatching' "$SRC/ips.hpp" || { echo '[FATAL] Not the enumerating IPS v25 source' >&2; exit 3; }
# Compact-only is the fastest *counting-backbone* configuration in the 13-data ST ablation.
# The v25 tested ET+TG combination also uses hashless + row-cache hybrid adjacency.
TWO_COMMON=(-O3 -std=c++17 -march=native -fopenmp -UNDEBUG -DIPS_ST_V24_SINGLE_DEFECT)
for mode in two_st two_st_hybrid two_et two_et_tg two_et_tg_compact; do
  flags=("${TWO_COMMON[@]}")
  case "$mode" in
    two_st) flags+=(-DIPS_CLASSIC_PIVOT -DIPS_DISABLE_ET);;
    two_st_hybrid) flags+=(-DIPS_CLASSIC_PIVOT -DIPS_DISABLE_ET -DIPS_ST_V15_HASHLESS -DIPS_ST_V15_ROW_CACHE);;
    two_et) flags+=(-DIPS_CLASSIC_PIVOT);;
    two_et_tg) flags+=(-DIPS_ST_V15_HASHLESS -DIPS_ST_V15_ROW_CACHE);;
    two_et_tg_compact) :;;
  esac
  echo "[TWO_BUILD] $mode from v25 explicit enumerator"
  g++ "${flags[@]}" -I "$SRC" "$SRC/main.cpp" -o "$HERE/bin/$mode"
done
echo '[BUILD_COMPLETE] five double modes + two single executables'
