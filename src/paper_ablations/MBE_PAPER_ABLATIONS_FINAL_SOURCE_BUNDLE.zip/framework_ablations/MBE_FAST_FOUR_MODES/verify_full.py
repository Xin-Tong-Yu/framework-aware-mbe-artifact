#!/usr/bin/env python3
"""Exact biclique-set oracle across one-sided V63 and explicitly enumerating IPS v25.
Input test graphs use .clean with a true L R E header. No two-side counting shortcut.
"""
import argparse
from pathlib import Path
import random
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
MODES = ('one_st', 'one_et', 'one_et_tg', 'two_st', 'two_st_hybrid', 'two_et', 'two_et_tg', 'two_et_tg_compact')

def oracle(nl,nr,edges,ll,rr):
    ans=set()
    for mask in range(1,1<<nl):
        left=frozenset(i for i in range(nl) if mask>>i&1)
        right=frozenset(j for j in range(nr) if all((i,j) in edges for i in left))
        if len(right)<rr: continue
        closed=frozenset(i for i in range(nl) if all((i,j) in edges for j in right))
        if closed==left and len(left)>=ll:
            ans.add((tuple(sorted(left)),tuple(sorted(right))))
    return ans

def parse_one(s):
    res=[]
    for m in re.finditer(r'^\[([0-9, ]*)\]\[([0-9, ]*)\]$',s,re.M):
        res.append((tuple(sorted(int(i.strip()) for i in m[1].split(',') if i.strip())),
                    tuple(sorted(int(i.strip()) for i in m[2].split(',') if i.strip()))))
    return res

def parse_two(s):
    res=[]
    for ln in s.splitlines():
        a,b=ln.split('|')
        a=list(map(int,a.split())); b=list(map(int,b.split()))
        assert a[0]==len(a)-1 and b[0]==len(b)-1
        res.append((tuple(sorted(a[1:])),tuple(sorted(b[1:]))))
    return res

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--cases',type=int,default=50)
    ap.add_argument('--seed',type=int,default=196002)
    a=ap.parse_args(); rng=random.Random(a.seed)
    with tempfile.TemporaryDirectory() as t:
        t=Path(t)
        for z in range(a.cases):
            nl=rng.randint(2,7); nr=rng.randint(2,7)
            p=[.08,.21,.48,.72,.92][z%5]
            edges={(i,j) for i in range(nl) for j in range(nr) if rng.random()<p}
            if z%7==0:
                nl=nr=rng.randint(3,7)
                edges={(i,j) for i in range(nl) for j in range(nr) if i!=j}
            if not edges: edges.add((rng.randrange(nl),rng.randrange(nr)))
            ll,rr=rng.choice(((1,1),(2,1),(1,2),(2,2)))
            f=t/'sample.clean';f.write_text(f'{nl} {nr} {len(edges)}\n'+''.join(f'{i} {j}\n' for i,j in sorted(edges)))
            expected=oracle(nl,nr,edges,ll,rr)
            for mode in MODES:
                out=t/(mode+'.out')
                cmd=['bash',str(HERE/'run.sh'),mode,str(f)]
                if mode.startswith('one_'):
                    cmd+=['--emit','stdout']
                else:
                    cmd+=['-o',str(out)]
                cmd+=['-l',str(ll),'-r',str(rr)]
                r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
                if r.returncode: raise RuntimeError(f'case={z} {mode}: {r.stdout[-500:]}\n{r.stderr[-500:]}')
                got=parse_one(r.stdout) if mode.startswith('one_') else parse_two(out.read_text())
                if len(got)!=len(set(got)) or set(got)!=expected:
                    raise AssertionError(f'case={z} mode={mode} edges={sorted(edges)} min={ll,rr} expected={sorted(expected)} got={sorted(got)}')
            if (z+1)%10==0: print(f'[ORACLE] {z+1}/{a.cases} graphs; {8*(z+1)} full-set checks PASS',flush=True)
    print(f'[ORACLE_PASS] graphs={a.cases} full_set_comparisons={len(MODES)*a.cases}')

if __name__=='__main__': main()
