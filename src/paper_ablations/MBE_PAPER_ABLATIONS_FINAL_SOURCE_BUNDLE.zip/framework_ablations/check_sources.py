#!/usr/bin/env python3
"""Read-only dependency check. Does not compile and does not change any data."""
from pathlib import Path
import shutil,sys
root=Path(__file__).resolve().parent
required={
 'Single final code': 'MBE_FAST_FOUR_MODES/one/source/src/MBET.hpp',
 'Double final code': 'MBE_CORRECTED_13DATA/two_source/ips.hpp',
 'Correct header converter': 'MBE_CORRECTED_13DATA/prepare_corrected.py',
 'Single full baseline code': 'MBE_NEW_P0_20261109/original_mbet/src/MBET.hpp',
 'P0 paired runner': 'MBE_NEW_P0_20261109/bench.py',
 'Candidate Tree runner': 'V63_MBET_CORE_SELECT/v63_run.py',
 'Result Tree/CR runner': 'MBE_ST_CR_2X2_20261108/bench.py',
 'IPS published source': 'IPS-main/src/ips.hpp',
 'MBET published source': 'MBET-master/src/MBET.hpp',
 'Native IPS study': 'IPS_ST_ABLATION_13DATA/run_ips_ablation.py',
}
fail=[]
for label,relative in required.items():
 p=root/relative
 if p.is_file(): print('[SOURCE_OK]',label,relative)
 else: print('[SOURCE_MISSING]',label,relative);fail.append(relative)
for program in ['g++','cmake','python3','bash','taskset']:
 print('[TOOL_'+('OK' if shutil.which(program) else 'MISSING')+']',program)
 if not shutil.which(program):fail.append(program)
print('[DATA]', '13-graph data_clean linked/present' if (root/'data_clean').is_dir() else 'not connected; use setup-data')
if fail:sys.exit(2)
print('[SOURCE_CHECK_PASS]')
