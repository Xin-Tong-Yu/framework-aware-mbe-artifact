#!/usr/bin/env python3
"""Controlled MBET Result Tree child layout x compressed result reporting.
Preserves the original six-mode checkpoint and builds separate executables.
This factorial isolates only these two toggles, NOT all ST improvements.
"""
import argparse,datetime as dt,hashlib,json,math,os,random,re,resource,statistics,subprocess,sys,time
from pathlib import Path
GRAPH_NAMES=('youtube','actors','stackoverflow','bibsonomy','dblp','forum','ukwiki','escorts','github','bkcrossing','twitter','imdb','amazon')
MODES={'flat_no_cr':(False,False), 'flat_cr':(False,True), 'inline_no_cr':(True,False), 'inline_cr':(True,True)}
CFLAGS=['-DCMAKE_BUILD_TYPE=Release','-DCMAKE_CXX_FLAGS_RELEASE=-O3 -UNDEBUG',
 '-DMBE_ET_STREAM=ON','-DMBE_V32_CANDIDATE_POOL=ON','-DMBE_V32_RESULT_POOL=ON',
 '-DMBE_V31_RESULT_HOT=OFF','-DMBE_V31_FORK_PATH=OFF',
 '-DMBE_V40_FLAT_RESULT=ON','-DMBE_V40_FLAT_CANDIDATE=OFF',
 '-DMBE_V52_INLINE_FORK_SCRATCH=ON','-DMBE_V61_FAST_RESULT_APPEND=OFF',
 '-DMBE_ET13_DIAG=OFF','-DMBE_V58_COST_PROFILE=OFF',
 '-DMBE_V63_INLINE_CANDIDATE=ON','-DMBE_V30_SKIP_EMPTY_PREV=ON']
COMMON=['--st','on','-l','1','-r','1','--orientation','auto-size',
 '--et-root-summary','on','--et-cardinality-gate','on',
 '--tg-prefix-cap','8','--tg-two-min-family','8',
 '--v56-min-paths','5','--v56-max-paths','32','--v56-max-cols','128',
 '--v56-max-bits','12','--v56-component-cap','10',
 '--et','off','--tg','off','--kappa','1','--v56-terminal','0','--v56-prefork','off']

def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
 return h.hexdigest()

def build(root,here):
 src=root/'MBE_FAST_FOUR_MODES'/'one'/'source'
 if not (src/'src'/'MBET.hpp').is_file(): raise RuntimeError('MBET source missing: '+str(src))
 for name,(inline,cr) in MODES.items():
  builddir=here/'build'/name
  opts=CFLAGS+[f'-DMBE_V42_INLINE_RESULT={"ON" if inline else "OFF"}',
                f'-DMBE_V42_FAST_REPORT={"ON" if cr else "OFF"}']
  print('[BUILD]',name,flush=True)
  subprocess.run(['cmake','-S',str(src),'-B',str(builddir),*opts],check=True,cwd=root)
  subprocess.run(['cmake','--build',str(builddir),'--parallel','2'],check=True,cwd=root)

def run_one(exe,graph,cpu,timeout):
 cmd=[str(exe),'-f',str(graph),*COMMON]
 def set_cpu():
  if cpu is not None:os.sched_setaffinity(0,{cpu})
 if Path('/usr/bin/time').is_file():cmd=['/usr/bin/time','-f','MAX_RSS_KB=%M',*cmd]
 start=time.monotonic()
 try:
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
    text=True,encoding='utf8',errors='replace',timeout=timeout,preexec_fn=set_cpu)
 except subprocess.TimeoutExpired:
  return dict(status='TIMEOUT',wall_s=round(time.monotonic()-start,4))
 except Exception as e:
  return dict(status='ERROR',detail=repr(e),wall_s=round(time.monotonic()-start,4))
 wall=time.monotonic()-start
 if r.returncode:
  return dict(status='ERROR',detail=f'Exit {r.returncode}: {r.stderr[-400:]} {r.stdout[-300:]}',wall_s=round(wall,4))
 def get(p,cast=int):
  x=re.search(p,r.stdout,re.M)
  return cast(x.group(1)) if x else None
 count=get(r'^Count:\s*(\d+)\s*$')
 xo=get(r'^Checksum_XOR:\s*(\d+)\s*$')
 su=get(r'^Checksum_SUM:\s*(\d+)\s*$')
 ms=get(r'^Search_Time_ms:\s*([\d.]+)\s*$',float)
 rss=re.search(r'MAX_RSS_KB=(\d+)',r.stderr)
 m=re.search(r'^Modules:\s*ST=on\s+ET=(on|off)\s+TG=(on|off)',r.stdout,re.M)
 if None in (count,xo,su,ms) or not m or m.groups()!=('off','off') or ms<=0:
  return dict(status='ERROR',detail='Failed parse ST-only result: '+r.stdout[-600:],wall_s=round(wall,4))
 return dict(status='OK',count=count,xor=xo,sum=su,ms=ms,wall_s=round(wall,4),rss_kb=int(rss.group(1)) if rss else None)

def midpoint(a,b):return (a+b)/2

def summarize(meta,blocks,failed,here):
 lines=['# Controlled Result Tree child layout x Compressed Reporting (CR)',
  '# flat=ordered child array, inline=0/1-child inline. Candidate layout and Fork cursor fixed.',
  '# CR may change the fingerprint HASH ALGORITHM; compare COUNT across CR states, not XOR/SUM.',
  '# Ratios > 1 mean faster. All timing is each program Search_Time_ms.',
  '[META] '+json.dumps(meta,sort_keys=True,ensure_ascii=False)]
 ratios={m:{} for m in MODES if m!='flat_no_cr'}
 ratios.update({x:{} for x in ('cr_gain_flat','cr_gain_inline','inline_gain_no_cr','inline_gain_cr')})
 for ds in meta['datasets']:
  bks=blocks.get(ds,[]);complete=[b for b in bks if b.get('completed') and b.get('validation')=='PASS']
  lines.append(f'\n[DATASET] {ds} completed={len(complete)}/{meta["runs"]}'+(f' FAILED={failed[ds]}' if ds in failed else ''))
  by={k:[] for k in ratios}
  for ib,b in enumerate(complete,1):
   rows=b['jobs']; a=rows[0]['ms']; z=rows[-1]['ms']; ref=midpoint(a,z)
   val={r['mode']:r['ms'] for r in rows if r['mode'] not in ('flat_no_cr_begin','flat_no_cr_end')}
   lines.append('[BLOCK] %d anchor_ms=%.4f,%.4f '%(ib,a,z)+' '.join(f'{k}={v:.4f}' for k,v in val.items()))
   for k,v in val.items():by[k].append(ref/v)
   by['cr_gain_flat'].append(ref/val['flat_cr'])
   by['cr_gain_inline'].append(val['inline_no_cr']/val['inline_cr'])
   by['inline_gain_no_cr'].append(ref/val['inline_no_cr'])
   by['inline_gain_cr'].append(val['flat_cr']/val['inline_cr'])
  for k,vs in by.items():
   if vs and len(vs)==meta['runs']:
    ratios[k][ds]=statistics.median(vs)
    lines.append('[PAIRED] %-22s median_speedup=%.5fx %s'%(k,statistics.median(vs),','.join(f'{x:.5f}' for x in vs)))
 for k,dsvals in ratios.items():
  if len(dsvals)==len(meta['datasets']):
   gm=math.exp(sum(math.log(v) for v in dsvals.values())/len(dsvals))
   lines.append(f'[GM_COMPLETE] {k} gm={gm:.6f}x datasets={len(dsvals)}')
  else:lines.append(f'[GM_INCOMPLETE] {k} completed={len(dsvals)}/{len(meta["datasets"])}')
 rep=here/'diagnostics'/'MBE_ST_CR_2X2_REPORT.txt';rep.parent.mkdir(parents=True,exist_ok=True)
 rep.write_text('\n'.join(lines)+'\n',encoding='utf8')

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--project-root',type=Path,default=Path(__file__).resolve().parent.parent)
 ap.add_argument('--datasets',nargs='+',default=list(GRAPH_NAMES))
 ap.add_argument('--runs',type=int,default=5)
 ap.add_argument('--timeout',type=int,default=1200)
 ap.add_argument('--cpu',default='auto')
 ap.add_argument('--skip-build',action='store_true')
 ap.add_argument('--fresh',action='store_true',help='CAUTION: clear this factorial checkpoint only')
 ap.add_argument('--process-only',nargs='+')
 ap.add_argument('--retry-failed',action='store_true')
 args=ap.parse_args()
 if args.runs<1 or args.timeout<1:ap.error('invalid runs or timeout')
 if any(x not in GRAPH_NAMES for x in args.datasets):ap.error('unknown graph')
 if args.process_only and any(x not in args.datasets for x in args.process_only):ap.error('--process-only outside --datasets')
 root=args.project_root.resolve();here=Path(__file__).resolve().parent
 sys.path.insert(0,str(root/'MBE_CORRECTED_13DATA'))
 try:from prepare_corrected import prepare_corrected
 except ImportError as e:ap.error(f'corrected data preparer absent: {e}')
 try:from known_counts import KNOWN_COUNT
 except ImportError as e:ap.error(f'known counts absent: {e}')
 if args.cpu=='auto':cpu=min(os.sched_getaffinity(0))
 elif args.cpu=='none':cpu=None
 else:
  cpu=int(args.cpu)
  if cpu not in os.sched_getaffinity(0):ap.error('CPU not available: '+str(cpu))
 if not args.skip_build:build(root,here)
 exes={k:here/'build'/k/'mbet_fast' for k in MODES}
 for k,p in exes.items():
  if not p.is_file():ap.error(f'{p} missing; first run without --skip-build')
 paths={ds:root/'data_clean'/(ds+'.txt') for ds in args.datasets}
 for ds,p in paths.items():
  if not p.is_file():ap.error(f'data missing: {p}')
 meta=dict(program='MBE_RESULT_CHILD_LAYOUT_X_CR_20261108',created=dt.datetime.now(dt.timezone.utc).isoformat(),
  root=str(root),datasets=list(args.datasets),runs=args.runs,timeout=args.timeout,cpu=cpu,
  binaries={k:digest(p) for k,p in exes.items()},inputs={d:digest(p) for d,p in paths.items()},
  comparison='flat/inline Result Tree child layout x CR; other switches held fixed',
  crcaveat='CR mode changes hash algorithm; only COUNT comparable between CR on and off')
 checkpoint=here/'diagnostics'/'MBE_ST_CR_2X2_CHECKPOINT.json';checkpoint.parent.mkdir(parents=True,exist_ok=True)
 if checkpoint.is_file() and not args.fresh:
  old=json.loads(checkpoint.read_text()); m=old['meta'].copy();n=meta.copy()
  m.pop('created',None);n.pop('created',None)
  if m!=n:ap.error('Checkpoint and args/binaries do not match; DO NOT overwrite it. If intentional rename the old checkpoint or use --fresh.')
  blocks=old['blocks'];failed=old.get('failed',{});print('[RESUME] previous complete blocks retained',flush=True)
 else:blocks={};failed={}
 def persist():
  obj=dict(meta=meta,blocks=blocks,failed=failed)
  tmp=checkpoint.with_suffix('.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8');tmp.replace(checkpoint)
  summarize(meta,blocks,failed,here)
 persist()
 for ds in args.datasets:
  if args.process_only and ds not in args.process_only:continue
  if ds in failed and not args.retry_failed:
   print('[SKIP_FAILED]',ds,failed[ds],flush=True);continue
  if args.retry_failed:failed.pop(ds,None)
  infile=paths[ds];nohdr=root/'MBE_CORRECTED_13DATA'/'.cache'/(ds+'.one.txt')
  if nohdr.exists() and (infile.stat().st_mtime > nohdr.stat().st_mtime):pass
  print('[PREPARE]',ds,flush=True)
  try:prepare_corrected(infile,nohdr,root/'MBE_CORRECTED_13DATA'/'.cache'/(ds+'.two.clean'),root/'MBE_CORRECTED_13DATA'/'.cache'/(ds+'.meta.json'))
  except Exception as e:
   failed[ds]=f'PREPARE: {e!r}';persist();print('[FAIL_PREPARE]',ds,failed[ds],flush=True);continue
  bks=blocks.setdefault(ds,[])
  while bks and not (bks[-1].get('completed') and bks[-1].get('validation')=='PASS'):
   bks.pop()
  for ib in range(len(bks),args.runs):
   rng=random.Random(26021108+12345*(args.datasets.index(ds)+1)+ib*733)
   middle=['flat_cr','inline_no_cr','inline_cr'];rng.shuffle(middle)
   seq=['flat_no_cr_begin',*middle,'flat_no_cr_end'];jobs=[]
   print(f'[BLOCK] {ds} {ib+1}/{args.runs}',flush=True)
   for tag in seq:
    m='flat_no_cr' if tag.startswith('flat_no_cr') else tag
    result=run_one(exes[m],nohdr,cpu,args.timeout)
    result['mode']=tag
    if result['status']=='OK' and result['count']!=KNOWN_COUNT[ds]:
     result['status']='ERROR';result['detail']=f'COUNT_MISMATCH got {result["count"]} expected {KNOWN_COUNT[ds]}'
    jobs.append(result)
    print(f'  [RUN] {tag} status={result["status"]} ms={result.get("ms", "NA")}',flush=True)
    if len(bks)==ib:bks.append(dict(completed=False,jobs=jobs))
    else:bks[-1]['jobs']=jobs
    persist()
    if result['status']!='OK':
     failed[ds]=f'{tag}: {result.get("detail",result["status"])}';persist();break
   if ds in failed:break
   # Fast report may have different hash values, but the two layout variants
   # with the SAME report setting must have identical Count/XOR/SUM.
   x={k:next((j for j in jobs if j['mode']==k),None) for k in seq}
   same_count=len({j['count'] for j in jobs})==1
   same_no_cr=(x['flat_no_cr_begin']['count'],x['flat_no_cr_begin']['xor'],x['flat_no_cr_begin']['sum'])==(x['inline_no_cr']['count'],x['inline_no_cr']['xor'],x['inline_no_cr']['sum'])==(x['flat_no_cr_end']['count'],x['flat_no_cr_end']['xor'],x['flat_no_cr_end']['sum'])
   # same CR hash within CR-on modes
   same_cr=(x['flat_cr']['count'],x['flat_cr']['xor'],x['flat_cr']['sum'])==(x['inline_cr']['count'],x['inline_cr']['xor'],x['inline_cr']['sum'])
   ok=same_count and same_no_cr and same_cr
   bks[-1].update(completed=True,validation='PASS' if ok else 'FAIL')
   if not ok:failed[ds]='Incorrect Count or within-report hash disagreement'
   persist();print('[BLOCK_DONE]',ds,ib+1,bks[-1]['validation'],flush=True)
   if not ok:break
 print('[REPORT]',here/'diagnostics'/'MBE_ST_CR_2X2_REPORT.txt',flush=True)
 print('[CHECKPOINT]',checkpoint,flush=True)

if __name__=='__main__':main()
