# Result Tree layout crossed with checksum reporting

Independent factorial ablation: flat/inline Result Tree child layout versus compressed reporting on/off, with Candidate Tree, ET, TG and fork settings fixed. Run `bash run_experiments.sh result-cr --runs 5 --timeout 1200`.

All run logs, timestamps, source hashes and dataset identifiers should be retained when reporting new measurements.
