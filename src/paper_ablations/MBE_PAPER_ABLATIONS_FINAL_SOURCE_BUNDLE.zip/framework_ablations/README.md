# Framework-aware experiment campaigns

The archive contains the established paper experiment runners: published Single versus optimized Single; Double vector/compact state; Candidate Tree child representation and fork cursor; Result Tree layout crossed with compressed reporting; standalone ST/ET/TG runs; and native IPS counting ablations. Use `run_experiments.sh` for all campaign commands.

All run logs, timestamps, source hashes and dataset identifiers should be retained when reporting new measurements.
